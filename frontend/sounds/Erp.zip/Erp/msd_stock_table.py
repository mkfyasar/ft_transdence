import psycopg2
from psycopg2.extras import RealDictCursor

db_config = {
    "host": "localhost",
    "database": "erpdb",
    "user":"ilge",
    "password":"123",
    "port":"5432"
}


def create_stock_table():
    try:
        conn = psycopg2.connect(**db_config)
        cursor = conn.cursor()
        
        table_name = "msd_stock"
        cursor.execute(f"""
            SELECT EXISTS (
                SELECT FROM information_schema.tables
                WHERE table_name = '{table_name}'
            );
        """)
        table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            print("Tablo Bulunamadı.!!!")
            
            create_table_query = f"""
           CREATE TABLE {table_name}(
                Barcode TEXT PRIMARY KEY NOT NULL,
                Process TEXT,
                Stock_Code TEXT,    
                Lot_Number TEXT,
                Quantity TEXT,
                Cabinet_Name TEXT,
                Placer_Person TEXT,
                Place_Date TIMESTAMP,
                Inside_Hum_Temp TEXT,
                Status TEXT,
                Outside_Start_time TIMESTAMP,
                Outside_Hum_Temp TEXT,
                Expire_Date TIMESTAMP,
                Package_Type TEXT,
                Thickness TEXT,
                Msl_Level TEXT,
                Msl_Countdown_Time TEXT,
                Msl_Time TEXT,
                Picker_Person TEXT,
                Picking_Date TIMESTAMP,
                Duration_In_Cabinet TIMESTAMP,
                Curing_Start_Date TIMESTAMP,
                Curing_Duration TIMESTAMP,
                Curing_End_Date TIMESTAMP,
                Location TEXT,
                Packaging_Date TIMESTAMP,
                Description TEXT
            );
            """
            cursor.execute(create_table_query)
            conn.commit()
            print(f"Tablo '{table_name}' oluşturuldu")
        else:
            print(f"Tablo '{table_name}' zaten mevcut")
    except Exception as e:
        print(f"Tablo oluşturulurken hata oluştu: {e}")
    finally:
        cursor.close()
        conn.close()
        
create_stock_table()
