import psycopg2
from psycopg2.extras import RealDictCursor

def get_connection():
    conn = psycopg2.connect(
        host="localhost",
        database="erpdb",
        user="ilge",
        password="123",
        port=5432
    )
    return conn


def create_ems_table():
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        table_name = "ems_table"  
        
        cursor.execute(f"""
            SELECT EXISTS (
                SELECT FROM information_schema.tables
                WHERE table_name = '{table_name}'
            );
        """)
        
        table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            print("Tablo Bulunamadı.!!!")
            
            create_table_query = f"""
           CREATE TABLE {table_name}(
                Barcode TEXT PRIMARY KEY NOT NULL,
                Stock_Code TEXT,
                Description TEXT,
                Quantity TEXT,
                Package_Type TEXT,
                Thickness TEXT,
                Msl_Level TEXT,
                Temp TEXT,
                Location TEXT,
                Expire_Date TIMESTAMP
            );
            """
            cursor.execute(create_table_query)
            conn.commit()
            print(f"Tablo '{table_name}' oluşturuldu")
        else:
            print(f"Tablo '{table_name}' zaten mevcut")
    except Exception as e:
        print(f"Tablo oluşturulurken hata oluştu: {e}")
    finally:
        cursor.close()
        conn.close()

create_ems_table()