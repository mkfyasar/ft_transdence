import psycopg2
from psycopg2.extras import RealDictCursor
import csv

def get_connection():
    conn = psycopg2.connect(
        host="localhost",
        database="erpdb",
        user="ilge",
        password="123",
        port=5432
    )
    return conn

csv_file_path = "raf_omru.csv"

def create_raf_omru_table(csv_file_path):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        table_name = "raf_omru_table"
        cursor.execute(f"""
            SELECT EXISTS (
                SELECT FROM information_schema.tables
                WHERE table_name = '{table_name}'
            );
        """)
        
        table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            
            create_table_query = f"""
            CREATE TABLE {table_name}(
                Msl_Levels TEXT,
                Duration TEXT,
                Temperature INT,
                Humidity INT
            );
            """
            cursor.execute(create_table_query)
            conn.commit()
            print(f"Tablo '{table_name}' oluşturuldu")
        else:
            print(f"Tablo '{table_name}' zaten mevcut")
        
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        row_count = cursor.fetchone()[0]
        
        if row_count == 0:
            with open(csv_file_path, "r") as file:
                csv_reader = csv.reader(file)
                next(csv_reader)
                for row_number, row in enumerate(csv_reader, start=2):
                    if len(row) != 4:
                        print(f"{row_number}. satırda 4 sütun olmalı")
                        continue
                    insert_query = f"""
                    INSERT INTO {table_name} (Msl_Levels, Duration, Temperature, Humidity)
                    VALUES ('{"','".join(row)}');
                    """
                    cursor.execute(insert_query)
                conn.commit()
                print("Veriler tabloya eklendi")
        else:
            print("Tablo dolu")
    except Exception as e:
        print(f"Tablo oluşturulurken hata oluştu: {e}")
        
    finally:
        if conn:
            cursor.close()
            conn.close()
            
create_raf_omru_table(csv_file_path) 