import gradio as gr
import pandas as pd
import sqlite3

# SQLite ile bir örnek veritabanı (kendi SQL bağlantınızı ayarlayın)
conn = sqlite3.connect("stocks.db")
cursor = conn.cursor()

# Örnek tablo oluştur
cursor.execute("""
CREATE TABLE IF NOT EXISTS stocks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    price REAL
)
""")
conn.commit()

# Örnek veri ekle
cursor.executemany("INSERT INTO stocks (name, price) VALUES (?, ?)", [
    ("Stock A", 100.5),
    ("Stock B", 200.3),
    ("Stock C", 150.0)
])
conn.commit()

# SQL'den veriyi çekmek için bir fonksiyon
def fetch_stocks():
    query = "SELECT * FROM stocks"
    df = pd.read_sql_query(query, conn)
    return df

# SQL'den bir satırı silmek için bir fonksiyon
def delete_stock(row_id):
    cursor.execute("DELETE FROM stocks WHERE id = ?", (row_id,))
    conn.commit()
    return fetch_stocks()

# Gradio'da tabloyu güncelleme işlevi
def update_table():
    df = fetch_stocks()
    return df

with gr.Blocks() as demo:
    with gr.Row():
        table = gr.Dataframe(
            value=fetch_stocks(),
            headers=["ID", "Name", "Price"],
            interactive=False,
            label="Stock Table"
        )
        status = gr.Textbox(label="Status", interactive=False)

    with gr.Row():
        row_id_input = gr.Number(label="Row ID to Delete")
        delete_button = gr.Button("Delete Row")

    def delete_and_update(row_id):
        df = delete_stock(row_id)
        return df, f"Row with ID {row_id} deleted."

    delete_button.click(
        delete_and_update,
        inputs=[row_id_input],
        outputs=[table, status]
    )

demo.launch()
