from datetime import datetime

# Şu anki zamanı alır ve belirli bir formatta döndürür
def get_current_time():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


# Başlangıç ve bitiş zamanları arasındaki farkı hesaplar
def calculate_time_difference(start_time, end_time):
    start_time = datetime.strptime(start_time, "%Y-%m-%d %H:%M")
    end_time = datetime.strptime(end_time, "%Y-%m-%d %H:%M")
    return end_time - start_time

# String formatındaki tarihi datetime objesine çevirir
def str_to_datetime(date_str):
    return datetime.strptime(date_str, "%Y-%m-%d %H:%M")

# datetime objesini string formatına çevirir
def datetime_to_str(date_time):
    return date_time.strftime("%Y-%m-%d %H:%M")

