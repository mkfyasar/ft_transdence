from fastapi import FastAPI, HTTPException, Form, Query
from erp_similation import execute_query
from pydantic import BaseModel
from fastapi.requests import Request
import logging
from typing import Optional
from datetime import datetime
from urllib.parse import unquote
from datetime import datetime, timedelta
########################### LOGLAMA ############################################

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
app = FastAPI()

@app.middleware("http")
async def log_requests(request: Request, call_next):
    logger.info(f"Gelen İstek: {request.method} {request.url}")
    body = await request.body()
    logger.info(f"İstek Gövdesi: {body.decode('utf-8')}")
    response = await call_next(request)
    logger.info(f"Giden Yanıt Durumu: {response.status_code}")
    return response

########################### LOGLAMA ############################################


########################### DATA MODELLERİ ############################################


class UpdateStockRequest(BaseModel):
    Stock_Code: Optional[str] = None
    Lot_Number: Optional[str] = None
    Quantity: Optional[str] = None
    Cabinet_Name: Optional[str] = None
    Placer_Person: Optional[str] = None
    Place_Date: Optional[datetime] = None
    Inside_Hum_Temp: Optional[str] = None
    Status: Optional[str] = None
    Outside_Start_Time: Optional[datetime] = None
    Outside_Hum_Temp: Optional[str] = None
    Expire_Date: Optional[datetime] = None
    Package_Type: Optional[str] = None
    Thickness: Optional[str] = None
    Msl_Level: Optional[str] = None
    Msl_Countdown_Time: Optional[str] = None
    Msl_Time: Optional[str] = None
    Picker_Person: Optional[str] = None
    Picking_Date: Optional[datetime] = None
    Duration_In_Cabinet: Optional[datetime] = None
    Curing_Start_Date: Optional[datetime] = None
    Curing_Duration: Optional[datetime] = None
    Curing_End_Date: Optional[datetime] = None
    Location: Optional[str] = None
    Packaging_Date: Optional[datetime] = None
    Description: Optional[str] = None


########################### DATA MODELLERİ ############################################






########################### GET METHOTLARI ############################################
@app.get("/get_stock/{Barcode}")
def get_stock(Barcode: str):
    query = """
    SELECT
        Barcode,
        Stock_Code,
        Lot_Number,
        Quantity,
        Cabinet_Name,
        Placer_Person,
        Place_Date,
        Inside_Hum_Temp,
        Status,
        Outside_Start_Time,
        Outside_Hum_Temp,
        Expire_Date,
        Package_Type,
        Thickness,
        MSL_Level,
        MSL_Countdown_Time,
        MSL_Time,
        Picker_Person,
        Picking_Date,
        Duration_In_Cabinet,
        Curing_Start_Date,
        Curing_Duration,
        Curing_End_Date,
        Location,
        Packaging_Date,
        Description
    FROM public.msd_stock
    WHERE Barcode = %s
    """
    try:
        result = execute_query(query, (Barcode,))
        if result:
            return {"stock": result[0]}
        else:
            raise HTTPException(status_code=404, detail="Stock not found")
    except Exception as e:
        print(f"Database error: {e}")
        raise HTTPException(status_code=500, detail=f"An error occurred while retrieving stock: {e}")

@app.get("/get_stocks")
def get_stocks():
    query = """
    SELECT
        Barcode,
        Stock_Code,
        Lot_Number,
        Quantity,
        Cabinet_Name,
        Placer_Person,
        Place_Date,
        Inside_Hum_Temp,
        Status,
        Outside_Start_Time,
        Outside_Hum_Temp,
        Expire_Date,
        Package_Type,
        Thickness,
        MSL_Level,
        MSL_Countdown_Time,
        MSL_Time,
        Picker_Person,
        Picking_Date,
        Duration_In_Cabinet,
        Curing_Start_Date,
        Curing_Duration,
        Curing_End_Date,
        Location,
        Packaging_Date,
        Description
    FROM public.msd_stock
    """
    try:
        result = execute_query(query)
        if result:
            return {"stocks": result}
        else:
            raise HTTPException(status_code=404, detail="Stocks not found")
    except Exception as e:
        print(f"Database error: {e}")
        raise HTTPException(status_code=500, detail=f"An error occurred while retrieving stocks: {e}")



@app.get("/get_solderpaste")
def get_solderpaste():
    query = """
    SELECT
        Barcode,
        Stock_Code,
        Lot_Number,
        Quantity,
        Cabinet_Name,
        Placer_Person,
        Place_Date,
        Inside_Hum_Temp,
        Status,
        Outside_Start_Time,
        Outside_Hum_Temp,
        Expire_Date,
        Package_Type,
        Thickness,
        MSL_Level,
        MSL_Countdown_Time,
        MSL_Time,
        Picker_Person,
        Picking_Date,
        Duration_In_Cabinet,
        Curing_Start_Date,
        Curing_Duration,
        Curing_End_Date,
        Location,
        Packaging_Date,
        Description
    FROM msd_solderpaste
    """
    try:
        result = execute_query(query)
        if result:
            return {"stocks": result}
        else:
            raise HTTPException(status_code=404, detail="Stocks not found")
    except Exception as e:
        print(f"Database error: {e}")
        raise HTTPException(status_code=500, detail=f"An error occurred while retrieving stocks: {e}")
    
    
@app.get("/get_moisture")
def get_moisture():
    query = """
    SELECT
        Barcode,
        Stock_Code,
        Lot_Number,
        Quantity,
        Cabinet_Name,
        Placer_Person,
        Place_Date,
        Inside_Hum_Temp,
        Status,
        Outside_Start_Time,
        Outside_Hum_Temp,
        Expire_Date,
        Package_Type,
        Thickness,
        MSL_Level,
        MSL_Countdown_Time,
        MSL_Time,
        Picker_Person,
        Picking_Date,
        Duration_In_Cabinet,
        Curing_Start_Date,
        Curing_Duration,
        Curing_End_Date,
        Location,
        Packaging_Date,
        Description
    FROM public.msd_moisture
    """
    try:
        result = execute_query(query)
        if result:
            return {"stocks": result}
        else:
            raise HTTPException(status_code=404, detail="Stocks not found")
    except Exception as e:
        print(f"Database error: {e}")
        raise HTTPException(status_code=500, detail=f"An error occurred while retrieving stocks: {e}")

@app.get("/get_logs")
def get_logs():
    query = """
    SELECT
        Id,
        Barcode,
        Stock_Code,
        Lot_Number,
        Quantity,
        Cabinet_Name,
        Placer_Person,
        Place_Date,
        Inside_Hum_Temp,
        Status,
        Outside_Start_Time,
        Outside_Hum_Temp,
        Expire_Date,
        Package_Type,
        Thickness,
        MSL_Level,
        MSL_Countdown_Time,
        MSL_Time,
        Picker_Person,
        Picking_Date,
        Duration_In_Cabinet,
        Curing_Start_Date,
        Curing_Duration,
        Curing_End_Date,
        Location,
        Packaging_Date,
        Description,
        Process
    FROM public.msd_log
    """
    try:
        result = execute_query(query)
        if result:
            return {"log": result}
        else:
            raise HTTPException(status_code=404, detail="Logs not found")
    except Exception as e:
        print(f"Database error: {e}")
        raise HTTPException(status_code=500, detail=f"An error occurred while retrieving logs: {e}")


#Kullanıcıları getirme
@app.get("/get_users")
def get_users():
    query = """
    SELECT 
      username,
      title,
      position,
      mail,
      status
    FROM public.users_db
    """
    result = execute_query(query)
    if result:
        return {"users": result}
    else:
        raise HTTPException(status_code=404, detail="users not found")

@app.get("/get_user/{username}")
def get_user(username: str):
    query = """
    SELECT
        username,
        title,
        position,
        mail,
        status
    FROM public.users_db
    WHERE username = %s
    """
    params = (username,)
    result = execute_query(query, params)
    if result:
        return {"user": result[0]}
    else:
        raise HTTPException(status_code=404, detail="user not found")
    
@app.get("/get_cabinets")
def get_cabinets():
    query = """
    SELECT
        Cabinet_Type,
        Cabinet_Name,
        Temperature,
        Colum,
        Row,
        Status
    FROM public.cabinet_table
    """
    result = execute_query(query)
    if result:
        return {"cabinets": result}
    else:
        raise HTTPException(status_code=404, detail="cabinets not found")

@app.get("/get_cabinets_name")
def get_cabinets_name():
    query = """
    SELECT
        Cabinet_Name
    FROM public.cabinet_table
    """
    result = execute_query(query)
    if result:
        return {"cabinets": result}
    else:
        raise HTTPException(status_code=404, detail="cabinets not found")
    
########################### GET METHOTLARI ##############################

    

########################### POST METHOTLARI ############################################

@app.post("/add_user")
def post_user(username: str, password: str, title: str, position: str, mail: str, status: str):
    query = """
    INSERT INTO public.users_db (
        username,
        password,
        title,
        position,
        mail,
        status
    ) VALUES (%s, %s, %s, %s, %s, %s)
    """
    params = (username, password, title, position, mail, status)
    try:
        execute_query(query, params)
    except Exception as e:
        raise HTTPException(status_code=500, detail="database error")
    return {"status": "success", "username": username}
  
@app.post("/add_cabinet")
def add_cabinet(cabinet_type: str, cabinet_name: str, temperature: str, colum: str, row: str, status: str, filled: str):
    query = """
    INSERT INTO cabinet_table (
        Cabinet_Type,
        Cabinet_Name,
        Temperature,
        Colum,
        Row,
        Status,
        Filled
    )
    VALUES (
        %(Cabinet_Type)s,
        %(Cabinet_Name)s,
        %(Temperature)s,
        %(Colum)s,
        %(Row)s,
        %(Status)s,
        %(Filled)s
    )
    """
    params = {
        "Cabinet_Type": cabinet_type,
        "Cabinet_Name": cabinet_name,
        "Temperature": temperature,
        "Colum": colum,
        "Row": row,
        "Status": "empty",
        "Filled": "0"
    }
    try:
        execute_query(query, params)
        return {"message": "Cabinet added successfully"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"An error occurred: {e}")
    
@app.post("/add_stock")
async def add_stock(
    barcode: str,
    stock_code: str,
    lot_number: str,
    quantity: str,
    cabinet_name: str,
    placer_person: str,
    place_date: datetime,
    inside_hum_temp: str,
    status: str,
    outside_start_time: datetime,
    outside_hum_temp: str,
    expire_date: datetime,
    package_type: str,
    thickness: str,
    msl_level: str,
    msl_countdown_time: str,
    MSL_Time: str,
    picker_person: str,
    picking_date: datetime,
    duration_in_cabinet: str,
    curing_start_date: datetime,
    curing_duration: str,
    curing_end_date: datetime,
    location: str,
    packaging_date: datetime,
    description: str
):
    query = """
    INSERT INTO public.msd_stock (
        Barcode,
        Stock_Code,
        Lot_Number,
        Quantity,
        Cabinet_Name,
        Placer_Person,
        Place_Date,
        Inside_Hum_Temp,
        Status,
        Outside_Start_Time,
        Outside_Hum_Temp,
        Expire_Date,
        Package_Type,
        Thickness,
        MSL_Level,
        MSL_Countdown_Time,
        MSL_Time,
        Picker_Person,
        Picking_Date,
        Duration_In_Cabinet,
        Curing_Start_Date,
        Curing_Duration,
        Curing_End_Date,
        Location,
        Packaging_Date,
        Description
    )
    VALUES (
        %(Barcode)s,
        %(Stock_Code)s,
        %(Lot_Number)s,
        %(Quantity)s,
        %(Cabinet_Name)s,
        %(Placer_Person)s,
        %(Place_Date)s,
        %(Inside_Hum_Temp)s,
        %(Status)s,
        %(Outside_Start_Time)s,
        %(Outside_Hum_Temp)s,
        %(Expire_Date)s,
        %(Package_Type)s,
        %(Thickness)s,
        %(MSL_Level)s,
        %(MSL_Countdown_Time)s,
        %(MSL_Time)s,
        %(Picker_Person)s,
        %(Picking_Date)s,
        %(Duration_In_Cabinet)s,
        %(Curing_Start_Date)s,
        %(Curing_Duration)s,
        %(Curing_End_Date)s,
        %(Location)s,
        %(Packaging_Date)s,
        %(Description)s
    )
    """
    params = {
        "Barcode": barcode,
        "Stock_Code": stock_code,
        "Lot_Number": lot_number,
        "Quantity": quantity,
        "Cabinet_Name": cabinet_name,
        "Placer_Person": placer_person,
        "Place_Date": place_date,
        "Inside_Hum_Temp": inside_hum_temp,
        "Status": status,
        "Outside_Start_Time": outside_start_time,
        "Outside_Hum_Temp": outside_hum_temp,
        "Expire_Date": expire_date,
        "Package_Type": package_type,
        "Thickness": thickness,
        "MSL_Level": msl_level,
        "MSL_Countdown_Time": msl_countdown_time,
        "MSL_Time": MSL_Time,
        "Picker_Person": picker_person,
        "Picking_Date": picking_date,
        "Duration_In_Cabinet": duration_in_cabinet,
        "Curing_Start_Date": curing_start_date,
        "Curing_Duration": curing_duration,
        "Curing_End_Date": curing_end_date,
        "Location": location,
        "Packaging_Date": packaging_date,
        "Description": description
    }
    try:
        # Veritabanı sorgusunu çalıştır
        execute_query(query, params)
        return {"message": "Stock added successfully"}
    except Exception as e:
        # Hata durumunda loglama yap
        print(f"Database error: {e}")  # veya logging kullanın
        raise HTTPException(
            status_code=400, 
            detail=f"An error occurred while adding stock: {e}"
        )

@app.post("/add_log")
async def add_log(
    barcode: str,
    stock_code: str,
    lot_number: str,
    quantity: str,
    cabinet_name: str,
    placer_person: str,
    place_date: datetime,
    inside_hum_temp: str,
    status: str,
    outside_start_time: datetime,
    outside_hum_temp: str,
    expire_date: datetime,
    package_type: str,
    thickness: str,
    msl_level: str,
    msl_countdown_time: str,
    MSL_Time: str,
    picker_person: str,
    picking_date: datetime,
    duration_in_cabinet: str,
    curing_start_date: datetime,
    curing_duration: str,
    curing_end_date: datetime,
    location: str,
    packaging_date: datetime,
    description: str,
    process: str
):
    query = """
    INSERT INTO public.msd_log (
        Barcode,
        Stock_Code,
        Lot_Number,
        Quantity,
        Cabinet_Name,
        Placer_Person,
        Place_Date,
        Inside_Hum_Temp,
        Status,
        Outside_Start_Time,
        Outside_Hum_Temp,
        Expire_Date,
        Package_Type,
        Thickness,
        MSL_Level,
        MSL_Countdown_Time,
        MSL_Time,
        Picker_Person,
        Picking_Date,
        Duration_In_Cabinet,
        Curing_Start_Date,
        Curing_Duration,
        Curing_End_Date,
        Location,
        Packaging_Date,
        Description,
        Process
    )
    VALUES (
        %(Barcode)s,
        %(Stock_Code)s,
        %(Lot_Number)s,
        %(Quantity)s,
        %(Cabinet_Name)s,
        %(Placer_Person)s,
        %(Place_Date)s,
        %(Inside_Hum_Temp)s,
        %(Status)s,
        %(Outside_Start_Time)s,
        %(Outside_Hum_Temp)s,
        %(Expire_Date)s,
        %(Package_Type)s,
        %(Thickness)s,
        %(MSL_Level)s,
        %(MSL_Countdown_Time)s,
        %(MSL_Time)s,
        %(Picker_Person)s,
        %(Picking_Date)s,
        %(Duration_In_Cabinet)s,
        %(Curing_Start_Date)s,
        %(Curing_Duration)s,
        %(Curing_End_Date)s,
        %(Location)s,
        %(Packaging_Date)s,
        %(Description)s,
        %(Process)s
    )
    """
    params = {
        "Barcode": barcode,
        "Stock_Code": stock_code,
        "Lot_Number": lot_number,
        "Quantity": quantity,
        "Cabinet_Name": cabinet_name,
        "Placer_Person": placer_person,
        "Place_Date": place_date,
        "Inside_Hum_Temp": inside_hum_temp,
        "Status": status,
        "Outside_Start_Time": outside_start_time,
        "Outside_Hum_Temp": outside_hum_temp,
        "Expire_Date": expire_date,
        "Package_Type": package_type,
        "Thickness": thickness,
        "MSL_Level": msl_level,
        "MSL_Countdown_Time": msl_countdown_time,
        "MSL_Time": MSL_Time,
        "Picker_Person": picker_person,
        "Picking_Date": picking_date,
        "Duration_In_Cabinet": duration_in_cabinet,
        "Curing_Start_Date": curing_start_date,
        "Curing_Duration": curing_duration,
        "Curing_End_Date": curing_end_date,
        "Location": location,
        "Packaging_Date": packaging_date,
        "Description": description,
        "Process": process
    }
    try:
        # Veritabanı sorgusunu çalıştır
        execute_query(query, params)
        return {"message": "Logs added successfully"}
    except Exception as e:
        # Hata durumunda loglama yap
        print(f"Database error: {e}")  # veya logging kullanın
        raise HTTPException(
            status_code=400, 
            detail=f"An error occurred while adding log: {e}"
        )

@app.post("/add_cabinet")
def add_cabinet(cabinet_type: str, cabinet_name: str, temperature: str, colum: str, row: str, status: str, filled: str):
    query = """
    INSERT INTO public.cabinet_table (
        Cabinet_Type,
        Cabinet_Name,
        Temperature,
        Colum,
        Row,
        Status,
        Filled
    )
    VALUES (
        %(Cabinet_Type)s,
        %(Cabinet_Name)s,
        %(Temperature)s,
        %(Colum)s,
        %(Row)s,
        %(Status)s,
        %(Filled)s
    )
    """
    params = {
        "Cabinet_Type": cabinet_type,
        "Cabinet_Name": cabinet_name,
        "Temperature": temperature,
        "Colum": colum,
        "Row": row,
        "Status": status,
        "Filled": filled
    }
    try:
        execute_query(query, params)
        return {"message": "Cabinet added successfully"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"An error occurred: {e}")
    
@app.post("/login")
def login(username: str, password: str):
    query = """
    SELECT password , title
    FROM public.users_db 
    WHERE username = %s
    -- Sadece password sütununu seç
    """
    result = execute_query(query, (username,))

    if not result:
        raise HTTPException(status_code=404, detail="users not found.")

    hashed_db_password = result[0]['password']  # Veritabanından alınan hash
    title = result[0]['title'] # title bilgisini alıyoruz
    # Kullanıcının girdiği şifreyi hashle
    

    if password == hashed_db_password:
        return {"message": "True", "title": title} # Yanıta title ekleniyor
    else:
        raise HTTPException(status_code=401, detail="wrong password")



















########################### POST METHOTLARI ############################################


















########################### UPDATE METHOTLARI ############################################


@app.put("/update_stock/{Barcode}")
def update_stock(Barcode: str, stock_data: UpdateStockRequest):
    update_fields = [f"{key} = %s" for key, value in stock_data.dict().items() if value is not None]
    
    if not update_fields:
        raise HTTPException(status_code=400, detail="No data to update")
    
    query = f"""
    UPDATE public.msd_stock
    SET {', '.join(update_fields)}
    WHERE Barcode = %s
    RETURNING *;
    """
    print("Generated SQL Query:", query)
    
    params = [value for value in stock_data.dict().values() if value is not None] + [Barcode]
    print("Parameters:", params)
    
    try:
        updated_stock = execute_query(query, params, fetch_one=True)
        if updated_stock:
            return {"message": "Stock updated successfully", "updated_stock": updated_stock}
        else:
            raise HTTPException(status_code=404, detail="Stock not found")
    except Exception as e:
        print(f"Database error: {e}")
        raise HTTPException(status_code=500, detail="An error occurred while updating stock.")

########################### UPDATE METHOTLARI ############################################    



########################### DELETE METHOTLARI ############################################

@app.delete("/delete_user")
def delete_user(username: str):
    # Kullanıcıyı önceden kontrol et
    check_query = """
    SELECT * FROM public.users_db WHERE username = %s
    """
    delete_query = """
    DELETE FROM public.users_db
    WHERE username = %s
    RETURNING *
    """
    params = (username.strip(),)  # Boşlukları temizle
    try:
        existing_user = execute_query(check_query, params)
        if not existing_user:
            return {"status": "not found", "message": f"Kullanıcı '{username}' bulunamadı."}
        
        # Silme işlemini gerçekleştir
        result = execute_query(delete_query, params)
        return {"status": "success", "message": f"Kullanıcı adı '{username}' olan kullanıcı silindi."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Veritabanı hatası: {e}")


@app.delete("/delete_cabinet")
def delete_cabinet(cabinet_name: str):
    # Kabineti önceden kontrol et
    check_query = """
    SELECT * FROM public.cabinet_table WHERE Cabinet_Name = %s
    """
    delete_query = """
    DELETE FROM public.cabinet_table
    WHERE Cabinet_Name = %s
    RETURNING *
    """
    params = (cabinet_name.strip(),)
    try:
        existing_cabinet = execute_query(check_query, params)
        if not existing_cabinet:
            return {"status": "not found", "message": f"Kabinet '{cabinet_name}' bulunamadı."}
        result = execute_query(delete_query, params)
        return {"status": "success", "message": f"Kabinet adı '{cabinet_name}' olan kabinet silindi."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Veritabanı hatası: {e}")


@app.delete("/delete_stock")
def delete_stock(Barcode: str):
    check_query = """
    SELECT * FROM public.msd_stock WHERE Barcode = %s
    """
    delete_query = """
    DELETE FROM public.msd_stock
    WHERE Barcode = %s
    RETURNING *
    """
    params = (Barcode.strip(),)
    try:
        existing_stock = execute_query(check_query, params)
        if not existing_stock:
            return {"status": "not found", "message": f"Stok '{Barcode}' bulunamadı."}
        
        execute_query(delete_query, params)
        return {"status": "success", "message": f"Stok kodu '{Barcode}' olan stok silindi."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Veritabanı hatası: {e}")

########################### DELETE METHOTLARI ############################################





    
###########################KARŞI BAĞLANTI APİLERİ ############################################

@app.get("/their_db/{Barcode}")
def fetch_stock(Barcode: str):
    # SQL sorgusu: barcode ile eşleşen stock_code bilgisini al
    query = """
    SELECT 
        Barcode,
        Stock_Code,
        Description,
        Quantity,
        Package_Type,
        Thickness,
        Msl_Level,
        Temp,
        Location
    FROM ems_table
    WHERE Barcode = %s
    """
    stok  = execute_query(query, (Barcode,))

    if not stok:
        raise HTTPException(status_code=404, detail="Barkod bulunamadı")
    return {"status": "success", "data": stok}


###########################KARŞI BAĞLANTI APİLERİ ############################################




######################### HESAPLAMA APİLERİ ############################################

@app.get("/get_msl_time/{thickness}/{msl_level}")
def get_msl_time(thickness: str, msl_level: str):
    
   query = """
    SELECT
        package_body,
        level,
        bake_temp_125c_exceeding_72h,
        bake_temp_125c_within_72h,
        bake_temp_90c_exceeding_72h,
        bake_temp_90c_within_72h,
        bake_temp_40c_exceeding_72h,
        bake_temp_40c_within_72h
    FROM smd_bake_conditions
    WHERE package_body = %s AND level = %s;
    """

   result = execute_query(query, (thickness, msl_level))

   if result:
       return {"msl_time": result}
   else:
       raise HTTPException(status_code=404, detail="MSL time not found")


@app.get("/get_raf_omru/{msl_level}/{temperature}/{humidity}") #raf ömrü hesaplama
def get_raf_omru(msl_level: str, temperature: int, humidity: int):
    query = """
    SELECT
        Duration
    FROM raf_omru_table
    WHERE Msl_Levels = %s AND Temperature = %s AND Humidity = %s;
    """
    result = execute_query(query, (msl_level, temperature, humidity))
    if result:
        return result
    else:
        raise HTTPException(status_code=404, detail="Duration not found for given parameters")



@app.get("/get_list_in_items")
def get_list_in_status():
    query = """
    SELECT * FROM msd_stock
    WHERE Status = 'in';
    """
    result = execute_query(query)
    if result:
        return {"stock": result}
    else:
        raise HTTPException(status_code=404, detail="Stock not found")
    

@app.get("/get_list_out_items")
def get_list_out_status():
    query = """
    SELECT * FROM msd_stock
    WHERE Status = 'out';
    """
    result = execute_query(query)
    if result:
        return {"stock": result}
    else:
        raise HTTPException(status_code=404, detail="Stock not found") 

@app.get("/get_expired_items")
def get_list_expired_status():
    query = """
    SELECT * FROM msd_stock
    WHERE expire_date < CURRENT_TIMESTAMP;
    """
    result = execute_query(query)
    if result:
        return {"expired_items": result}
    else:
        raise HTTPException(status_code=404, detail="Stock not found")
    
######################### HESAPLAMA APİLERİ ############################################

    
    

