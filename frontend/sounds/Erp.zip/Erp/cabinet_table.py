import psycopg2
from psycopg2.extras import RealDictCursor

def get_connection():
    conn = psycopg2.connect(
        host="localhost",
        database="erpdb",
        user="ilge",
        password="123",
        port=5432
    )
    return conn


def create_cabinet_table():
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        table_name = "cabinet_table"
        
        cursor.execute(f"""
            SELECT EXISTS (
                SELECT FROM information_schema.tables
                WHERE table_name = '{table_name}'
            );
        """)
        
        table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            print("Tablo Bulunamadı.!!!")
            
            create_table_query = f"""
            CREATE TABLE {table_name}(
                Id SERIAL PRIMARY KEY,
                Cabinet_Type TEXT,
                Cabinet_Name TEXT,
                Temperature TEXT,
                Colum TEXT,
                Row TEXT,
                Status TEXT,
                Filled TEXT[][],
                Start_Time TIMESTAMP,
                End_Time TIMESTAMP
            );
            """
            cursor.execute(create_table_query)
            conn.commit()
            print(f"Tablo '{table_name}' oluşturuldu")
        else:
            print(f"Tablo '{table_name}' zaten mevcut")
    except Exception as e:
        print(f"Tablo oluşturulurken hata oluştu: {e}")
    finally:
        cursor.close()
        conn.close()

create_cabinet_table()