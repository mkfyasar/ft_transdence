import psycopg2
from psycopg2.extras import RealDictCursor

def get_connection():
    conn = psycopg2.connect(
        host="localhost",
        database="erpdb",
        user="ilge",
        password="123",
        port=5432
    )
    return conn

def execute_query(query, params=None, fetch_one=False):
    conn = None  # Veritabanı bağlantı nesnesi
    try:
        # Veritabanı bağlantısını oluştur
        conn = get_connection()
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            # SQL sorgusunu çalıştır
            cur.execute(query, params)

            # Eğer SELECT sorgusu ise
            if query.strip().lower().startswith("select"):
                return cur.fetchone() if fetch_one else cur.fetchall()

            # Eğer RETURNING içeren sorgu (örneğin INSERT veya UPDATE) ise sonucu dön
            elif "returning" in query.strip().lower():
                result = cur.fetchone()
                conn.commit()  # RETURNING işlemlerinden sonra commit et
                return result

            # Eğer bir UPDATE veya DELETE işlemi ise, commit et
            elif query.strip().lower().startswith(("update", "delete")):
                conn.commit()
                return {"message": "Query executed successfully", "affected_rows": cur.rowcount}

            # INSERT gibi diğer sorgular için commit işlemini gerçekleştir
            else:
                conn.commit()
                return {"message": "Query executed successfully"}

    except Exception as e:
        # Hata oluşursa rollback işlemi yap ve hatayı logla
        if conn:
            conn.rollback()
        print("Veritabanı işlem sırasında hata oluştu:", e)
        raise Exception(f"Database error: {str(e)}")

    finally:
        # Veritabanı bağlantısını kapat
        if conn is not None:
            conn.close()
            