import psycopg2
import csv
import os

#Postgresql bağlantı bilgileri
db_config = {
    "host": "localhost",
    "database": "erpdb",
    "user": "ilge",
    "password": "123",
    "port": "5432"
}

# Dosya Kontrol
csv_file_path = "smd_bake_conditions.csv"
if not os.path.exists(csv_file_path):
    print("csv dosyası bulunamadı.")



#PostgreSQl Bağlantısı
def create_table_and_insert_from_csv(csv_file_path):
    try:
        #Veritabanına Bağlan
        conn = psycopg2.connect(**db_config)
        cursor = conn.cursor()        
        
        #Tablo Adı
        table_name = "smd_bake_conditions"
        
        #TAblo kontrol
        cursor.execute(f"""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = '{table_name}'
            );
        """)
        table_exits = cursor.fetchone()[0]
        
        #Tablo Yoksa Oluşturulma
        if not table_exits:
            print("Tablo Bulunamadı.!!!")
            create_table_query = f"""
            CREATE TABLE {table_name}(
                package_body TEXT,
                level TEXT,
                bake_temp_125c_exceeding_72h TEXT,
                bake_temp_125c_within_72h TEXT,
                bake_temp_90c_exceeding_72h TEXT,
                bake_temp_90c_within_72h TEXT,
                bake_temp_40c_exceeding_72h TEXT,
                bake_temp_40c_within_72h TEXT
            );
            """
            cursor.execute(create_table_query)
            conn.commit()
            print(f"Tablo '{table_name}' oluşturudu")
        else:
            print(f"Tablo '{table_name}' zaten mevcut")
        
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        row_count = cursor.fetchone()[0]
        
        if row_count == 0:
            print("Tablo boş.Csv'den veriler ekleniyor...")
            with open(csv_file_path, mode="r") as csv_file:
                csv_reader = csv.reader(csv_file)
                next(csv_reader) # Başlık satırını atlama
                
                for row_number, row in enumerate(csv_reader, start=2):
                    if len(row) != 8:
                        print(f"Satır {row_number} eksik sütun içeriyor: {row}")
                        continue
                    
                    insert_query = f"""
                    INSERT INTO {table_name} (
                        package_body, level, bake_temp_125c_exceeding_72h, bake_temp_125c_within_72h,
                        bake_temp_90c_exceeding_72h, bake_temp_90c_within_72h,
                        bake_temp_40c_exceeding_72h, bake_temp_40c_within_72h
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                    """
                    cursor.execute(insert_query, row)
                conn.commit()
                print("CSV'deki veriler başarıyla tabloya eklendi.")
        else:
            print("Tablo zaten veri içeriyor. Veri eklenmedi.")
    except Exception as e:
        print("Hata oluştu:",e)
        
    finally:
        if conn:
            cursor.close()
            conn.close()
            

create_table_and_insert_from_csv(csv_file_path)