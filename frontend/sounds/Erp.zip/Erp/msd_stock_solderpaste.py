import gradio as gr
import pandas as pd

# Örnek bir DataFrame
data = {
    "Material ID": ["202409261115400", "202411211132020", "202411211132060"],
    "Manufacturer": ["Y.SARF.328", "Y.SARF.305", "Y.SARF.305"],
    "Status": ["OUT", "IN", "IN"],
    "Remaining Lifetime": ["37 Days 22h 25m", "89 Days 16h 2m", "89 Days 16h 23m"],
    "Expiration Date": ["11.01.2025", "4.03.2025", "4.03.2025"],
}
df = pd.DataFrame(data)

# Gradio Arayüzü
with gr.Blocks() as demo:
    with gr.Tabs():
        with gr.TabItem("LIFETIME"):
            gr.DataFrame(value=df, interactive=False)
        with gr.TabItem("RESET PROCESS"):
            gr.Text("Reset Process İçeriği Buraya Eklenebilir")
        with gr.TabItem("BAKING PROCESS"):
            gr.Text("Baking Process İçeriği Buraya Eklenebilir")

demo.launch()
