import requests
import json

# Base URL for the server
BASE_URL = "http://192.168.10.107:8000"

# Function to get data from /receive_data
def get_receive_data():
    try:
        # Send a GET request to /receive_data
        response = requests.get(f"{BASE_URL}/product/123")
        
        # Check if the request was successful
        if response.status_code == 200:
            # Print the received data
            data = response.json()
            print("Received Data:", json.dumps(data, indent=4))
        else:
            print(f"Error: {response.status_code}, {response.text}")
    
    except requests.exceptions.RequestException as e:
        print(f"Error in request: {e}")

# Sample data to post to /products
sample_product = {
    "urun_kodu": "5",
    "urun_adi": "KART1",
    "barkod_no": "123",
    "birimi": "IN",
    "skt": "2024-12-10",
    "sgt": "2025-01-01",
    "ms_level": 2,
    "package": "FIRIN",
    "thickness": 3.0
}

# Function to post data to /products
def post_product(product):
    try:
        # Send a POST request to /products with the product data
        response = requests.post(f"{BASE_URL}/receive_data", json=product)
        
        # Check if the request was successful
        if response.status_code == 200:
            print("Product added successfully:", response.json())
        else:
            print(f"Error: {response.status_code}, {response.text}")
    
    except requests.exceptions.RequestException as e:
        print(f"Error in request: {e}")

# Example Usage
if __name__ == "__main__":
    # Step 2: Post sample product data to /products
    post_product(sample_product)
    
    # Step 1: Get data from /receive_data
    get_receive_data()

