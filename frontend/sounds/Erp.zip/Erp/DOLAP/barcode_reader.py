import psycopg2


#Postgresql bağlantı bilgileri
db_config = {
    "host": "localhost",
    "database": "erpdb",
    "user": "ilge",
    "password": "123",
    "port": "5432"
}

def barcode_read(barcode):
    try:
        conn = psycopg2.connect(**db_config)
        cursor = conn.cursor()
        
        # Sorguyu çalıştır
        query = """
        SELECT stock_code, quantity, package, thickness, ms_level, shell
        FROM public."ERP_PROD_LİST"
        WHERE msd_barcode = %s;
        """
        
        cursor.execute(query, (barcode, ))
        result = cursor.fetchone()
        
        if result:
            print("Ürün Bilgileri:")
            print(f"Stock Code: {result[0]}")
            print(f"Quantity: {result[1]}")
            print(f"Package: {result[2]}")
            print(f"Thickness: {result[3]}")
            print(f"MS Level: {result[4]}")
            print(f"Shell: {result[5]}")
        else:
            print("Barkod bulunamadı.")
            
    except Exception as e:
        print("Hata oluştu:", e)
        
    finally:
        if conn:
            cursor.close()
            conn.close()
        

while True:
    barcode = str(input("Barkod Okutunuz: "))
    print(barcode)
    barcode_read(barcode)