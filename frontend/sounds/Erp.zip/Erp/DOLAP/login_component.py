import gradio as gr

def login(email, password):
    if email == "test@example.com" and password == "password123":
        return "Login successful!"
    return "Invalid email or password."

with gr.Blocks() as demo:
    with gr.Row():
        gr.Markdown("<h1 style='text-align: center; width: 100%;'>Log In</h1>", elem_id="title")
    
    with gr.Column(scale=1, min_width=300, elem_id="login-container"):
        email_input = gr.Textbox(label="Username", placeholder="")
        password_input = gr.Textbox(label="Password", type="password", placeholder="")
        login_button = gr.Button("Login")


# Custom CSS for styling
demo.css = """

#title {
    font-family: Arial, sans-serif;
    font-size: 24px;
    color: #333;
}

#login-container {
    margin: auto;
    background: #1c1b19;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    padding: 20px;
    max-width: 400px;
}

#login-container > div > div{
    background: #242320;
}

#login-container > button{
    background: #ce6400;
}

#login-container > button {
    background: #ce6400;
    color: white; 
    border: none; 
    padding: 10px 20px; 
    transition: background 0.3s ease;
}

#login-container > button:hover {
    background: #ff8c00; 
    cursor: pointer; 
}

#login-container > button:active {
    background: #a85400; 
    transform: scale(0.98); 
}

#login-container > button :hover{
    background: #00000;
}

.gr-text-input {
    margin-bottom: 15px;
}

.gr-button {
    width: 100%;
    background-color: #007BFF;
    color: white;
    font-size: 16px;
    border: none;
    padding: 10px;
    border-radius: 5px;
    cursor: pointer;
}

.gr-button:hover {
    background-color: #0056b3;
}
"""

demo.launch()
