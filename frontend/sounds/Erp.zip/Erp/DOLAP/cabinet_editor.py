import gradio as gr

# Function to update the background color of rows dynamically
def update_row_colors(row_index, column_index, color1, color2, current_colors, columns_count):
    row_index = int(row_index) - 1
    column_index = int(column_index) - 1
    
    # Update both div1 and div2 in the specified row and column
    current_colors[row_index][column_index] = (color1, color2)  # Store colors as a tuple
    updated_html = update_cabinet_layout(columns_count, current_colors)
    return updated_html, current_colors

# Function to dynamically change the layout of the cabinet
def update_cabinet_layout(columns_count, current_colors=None):
    rows = []
    
    for i in range(12):
        row_html = "<div style='display: flex; flex-direction: row; margin-bottom: 10px;'>"
        for j in range(columns_count):
            color1, color2 = current_colors[i][j] if current_colors else ("#ce6400", "#ce6400")  # Default colors for both divs
            row_html += f"""
            <div style='flex: 1; height: 50px; border-radius: 10px; border: 1px solid #ddd; margin: 5px; padding: 5px; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); background: linear-gradient(to bottom, #f9f9f9, #e9e9e9);'>
                <div style='height: 60%; background-color: {color1}; margin-bottom: 5px; border-radius: 8px;'></div>  <!-- Larger div with a little space below -->
                <div style='height: 35%; background-color: {color2}; border-radius: 8px;'></div>  <!-- Smaller div -->
            </div>
            """
        row_html += "</div>"
        rows.append(row_html)

    return "".join(rows)

default_colors = [[("#ce6400", "#ce6400")] * 4 for _ in range(12)]  # Default color tuples

with gr.Blocks() as ui:
    with gr.Row():
        with gr.Column(scale=1):
            gr.Markdown("### Cabinet", elem_id="cabinet-title")
            cabinet_display = gr.HTML(update_cabinet_layout(1, default_colors), elem_id="cabinet")

        with gr.Column(scale=2):
            gr.Markdown("### Controls")
            row_index = gr.Dropdown(choices=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], label="Row Index")
            column_index = gr.Dropdown(choices=[1, 2, 3, 4], label="Column Index")
            color_picker1 = gr.ColorPicker(label="Larger Div Color")  # Color for the larger div
            color_picker2 = gr.ColorPicker(label="Smaller Div Color")  # Color for the smaller div
            current_colors = gr.State(value=default_colors)
            update_button = gr.Button("Update Row Color")
            
            column_count_dd = gr.Dropdown(choices=[1, 2, 3, 4], label="Column Count")

            column_count_dd.change(
                fn=update_cabinet_layout,
                inputs=[column_count_dd, current_colors],
                outputs=[cabinet_display],
            )

            # Update the row color when the button is clicked
            update_button.click(
                update_row_colors,
                inputs=[row_index, column_index, color_picker1, color_picker2, current_colors, column_count_dd],
                outputs=[cabinet_display, current_colors],
            )

    with gr.Row():
        gr.Button("New", elem_id="new-button")
        gr.Button("Save", elem_id="save-button")

ui.launch()
