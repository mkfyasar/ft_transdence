import psycopg2
from datetime import datetime

# PostgreSQL bağlantı bilgileri
db_config = {
    "host": "localhost",
    "database": "erpdb",
    "user": "ilge",
    "password": "123",
    "port": "5432"
}


def format_duration(duration):
    """Zaman farkını gün, saat ve dakika cinsinden formatlar."""
    days, seconds = duration.days, duration.seconds
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60

    formatted = []
    if days > 0:
        formatted.append(f"{days} gün")
    if hours > 0:
        formatted.append(f"{hours} saat")
    if minutes > 0:
        formatted.append(f"{minutes} dakika")

    return ", ".join(formatted) if formatted else "0 dakika"




def create_table_if_not_exists():
    """Tabloyu kontrol eder, yoksa oluşturur."""
    try:
        conn = psycopg2.connect(**db_config)
        cursor = conn.cursor()

        table_name = "Barkod_Processes"
        cursor.execute(f"""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = '{table_name}'
            );
        """)
        table_exists = cursor.fetchone()[0]

        if not table_exists:
            create_table_query = f"""
            CREATE TABLE public."Barkod_Processes" (
                id SERIAL PRIMARY KEY,
                barkod TEXT NOT NULL,
                process TEXT NOT NULL CHECK (process IN ('in', 'out', 'record')),
                timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            """
            cursor.execute(create_table_query)
            conn.commit()
            print(f"Tablo '{table_name}' oluşturuldu.")
        else:
            print(f"Tablo '{table_name}' zaten mevcut.")

    except Exception as e:
        print("Tablo oluşturulurken hata oluştu:", e)
    finally:
        if conn:
            cursor.close()
            conn.close()

def log_barkod(barkod, process):
    """Barkod ve işlem türünü veritabanına kaydeder."""
    try:
        conn = psycopg2.connect(**db_config)
        cursor = conn.cursor()

        query = """
        INSERT INTO public."Barkod_Processes" (barkod, process, timestamp)
        VALUES (%s, %s, %s);
        """
        current_time = datetime.now()  # Mevcut tarih ve saat
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M")  # Yıl, Ay, Gün, Saat, Dakika
        cursor.execute(query, (barkod, process, formatted_time))
        conn.commit()

        print(f"Barkod '{barkod}' için '{process}' işlemi kaydedildi ({formatted_time}).")

    except Exception as e:
        print("Hata oluştu:", e)
    finally:
        if conn:
            cursor.close()
            conn.close()

def calculate_out_product(barkod):
    """OUT ve IN tarihlerini doğru şekilde çıkartır ve süreyi hesaplar."""
    try:
        conn = psycopg2.connect(**db_config)
        cursor = conn.cursor()

        # Barkodun en son OUT ve IN işlemlerini al
        query = """
        SELECT process, timestamp
        FROM public."Barkod_Processes"
        WHERE barkod = %s
        ORDER BY timestamp DESC;
        """
        cursor.execute(query, (barkod,))
        records = cursor.fetchall()

        # OUT ve IN işlemlerini bul
        out_time = None
        in_time = None
        for record in records:
            if record[0] == "out" and not out_time:
                out_time = record[1]
            elif record[0] == "in" and not in_time:
                in_time = record[1]

            # OUT ve IN zamanlarını bulduğumuzda döngüyü sonlandır
            if out_time and in_time:
                break

        if out_time and in_time:
            # Zaman farkını hesapla
            duration = in_time - out_time  # IN - OUT
            if duration.total_seconds() < 0:
                print(f"HATA: IN zamanı OUT zamanından önce olamaz!")
                return None

            formatted_duration = format_duration(duration)
            print(f"Barkod '{barkod}' dışarıda {formatted_duration} süre kaldı.")
            return formatted_duration
        elif out_time:
            print(f"Barkod '{barkod}' henüz geri IN yapılmadı.")
            return None
        else:
            print(f"Barkod '{barkod}' için OUT işlemi bulunamadı.")
            return None

    except Exception as e:
        print("Hata oluştu:", e)
    finally:
        if conn:
            cursor.close()
            conn.close()
            
            
# Program başlangıcı
create_table_if_not_exists()  # Tablo yoksa oluştur

while True:
    print("\nİşlem Seçin:")
    print("1: OUT İşlemi")
    print("2: IN İşlemi")
    print("3: Dışarıda Kalma Süresi Hesapla")
    print("4: Çıkış")

    choice = input("Seçiminiz: ")

    if choice == "1":
        barkod = input("Barkod Okutun: ")
        log_barkod(barkod, "out")
    elif choice == "2":
        barkod = input("Barkod Okutun: ")
        log_barkod(barkod, "in")
    elif choice == "3":
        barkod = input("Barkod Okutun: ")
        calculate_out_product(barkod)
    elif choice == "4":
        print("Programdan çıkılıyor.")
        break
    else:
        print("Geçersiz seçim. Tekrar deneyin.")
