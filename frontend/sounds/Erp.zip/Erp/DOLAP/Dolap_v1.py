import os
import json
import sqlite3
import requests
import subprocess
import pandas as pd
import gradio as gr
from datetime import datetime

base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)))

################# base css codes for UI #####################
css = """
@font-face {
    font-family: 'Oswald';
    src: url('/file=Ayarlar/Oswald.ttf') format('truetype');
}

@font-face {
    font-family: 'DS-DIGIB';
    src: url('Ayarlar/DS-DIGIB.TTF') format('truetype');
}
.info-box {
    padding: 10px;
    border: 1px gray solid;
    border-radius: 10px;
}

.time-display h2 {
    font-family: 'DS-DIGIB', sans-serif;
    font-size: 30pt;
    color: white;
    position: fixed;
    bottom: 0.6%;
    left: 2%;
    z-index: 2000;
    padding: 0;
    margin-top: auto; /* En alta itilmesini sağlar */
}

.logo-gozle {
    display: flex;
    justify-content: flex-start;
    position: fixed;
    top: -15px;
    left: -15px;
    z-index: 1500;
    padding: 0;
    width: 21%;
    height: 10%;
}

.logo-ilge {
    display: flex;
    justify-content: flex-end;
    position: fixed;
    bottom: 2%;
    right: 2%;
    z-index: 1500;
    padding: 0;
    width: 21%;
    height: 3%;
}

.header_hidden{
    position: relative;
    margin-top: 3%;
}

.footer_hidden {
    height: 10%;
}

.footer_title_hidden {
    font-size: 11pt;
}

.start-button, .stop-button {
    border: none;
    color: #ffffff;
    font-weight: bold;
    font-family: 'Oswald', sans-serif;
    font-size: 20pt;
    cursor: pointer;
}

.run-button img {
    width: 60px;  /* İkonun genişliğini ayarlayın */
    height: 60px; /* İkonun yüksekliğini ayarlayın */
}

#process-container {
    display: flex;
    justify-content: space-between;
    padding: 10px 50px 30px 50px;
}

.good-product-display h2 {
    font-family: 'Oswald', sans-serif;
    font-size: 30pt;
    color: green;
    position: relative; /* Konumlandırma */
    padding-top: 10;
    margin-top: auto; /* En alta itilmesini sağlar */
}

.defective-product-display h2 {
    font-family: 'Oswald', sans-serif;
    font-size: 30pt;
    color: red;
    position: relative; /* Konumlandırma */
    padding-top: 10;
    margin-top: auto; /* En alta itilmesini sağlar */
}

.total-product-display h2 {
    font-family: 'Oswald', sans-serif;
    font-size: 30pt;
    color: white;
    position: relative; /* Konumlandırma */
    padding-top: 10;
    margin-top: auto; /* En alta itilmesini sağlar */
}
.efficiency-display h2 {
    font-family: 'Oswald', sans-serif;
    font-size: 30pt;
    color: cyan;
    position: relative; /* Konumlandırma */
    padding-top: 10;
    margin-top: auto; /* En alta itilmesini sağlar */
}

#header_row {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    background-color: #003366;
    margin-left: 0;
    position: fixed;
    top: 0;
    left: 0;
    height: 7%;
    width: 100%;
    box-shadow: 0 -2px 5px rgba(0,0,0,0.2);
    z-index: 1000;
}

.header_title {
    display: flex;
    align-items: center;
    height: 100%;
    justify-content: center;
    font-family: 'Oswald', sans-serif;
    font-size: 2vw;
    letter-spacing: 2px;
    font-weight: bold;
    text-align: center;
    margin-left: 10px;
    width: 100%;
    color: #fff;
    padding: 10px;
}

.footer {
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #003366;
    color: #fff;
    font-size: 13pt;
    text-align: center;
    padding: 10px 20px;
    position: fixed;
    bottom: 0;
    left: 0;
    height: 7%;
    width: 100%;
    box-shadow: 0 -2px 5px rgba(0,0,0,0.2);
    z-index: 1000;
}

.content {
    margin-top: 80px; /* Header'ın altında boşluk bırakır */
    margin-bottom: 50px;
    display: flex;
    flex-direction: row;
}

.left-column {
    display: flex;
    flex-direction: column;
    justify-content: space-between;  /* Zaman göstergesini en alta iter */
    width: 25%;
    height: 100vh; /* Yüksekliği tüm görünüm alanını kaplayacak şekilde ayarlar */
}

.right-column {
    display: flex;
    
    flex-direction: column;
    width: 75%;
}

.logo-genel {
    padding: 0;
    margin: 0;
    flex: 0 0 auto;
    min-width: 40px;  /* Minimum genişliği ayarlıyoruz */
    max-width: 40px;  /* Maksimum genişliği ayarlıyoruz */
    flex-shrink: 1;   /* Container'ın küçülmesini sağlıyoruz */
}

.logo-genel img {
    width: 40px;  /* Resim boyutunu sabitliyoruz */
    height: 40px;
    margin: 0;
    padding: 0;
}

#icons {
    position: fixed;
    justify-content: flex-end;  /* Resimleri sağa yaslamak için */
    top: 1.5%;
    right: 2%;
    display: flex;
    flex-direction: row;  /* Resimleri yatay olarak hizalıyoruz */
    align-items: center;
    z-index: 1500;
    width: 20%; /* Butonların toplam genişliği kapsayıcıdan taşmayacak */
    padding: 0;
    margin: 0;
}

#icons img {
    width: 30px;  /* İkonun genişliğini ayarlayın */
    height: 30px; /* İkonun yüksekliğini ayarlayın */
}

.header-buttons {
    background: transparent;
    padding: 0;
    margin: 0 5px; /* Butonlar arasında boşluk bırakmak için */
    border: none;
    flex: 0 0 auto; /* Butonların genişliğini ikon boyutuna göre ayarlayın */
    width: 40px; /* İsteğe bağlı: Buton genişliğini manuel olarak ayarlayın */
    height: 40px; /* İsteğe bağlı: Buton yüksekliğini manuel olarak ayarlayın */
    display: flex; /* Buton içindeki içeriği flex ile hizalamak için */
    justify-content: center; /* İkonu butonun merkezine yerleştirmek için */
    align-items: center; /* Dikey olarak hizalamak için */
}

.motor-buttons {
    background: transparent;
    padding: 0;
    margin: 0 5px; /* Butonlar arasında boşluk bırakmak için */
    border: none;
    flex: 0 0 auto; /* Butonların genişliğini ikon boyutuna göre ayarlayın */
    width: 40px; /* İsteğe bağlı: Buton genişliğini manuel olarak ayarlayın */
    height: 40px; /* İsteğe bağlı: Buton yüksekliğini manuel olarak ayarlayın */
    display: flex; /* Buton içindeki içeriği flex ile hizalamak için */
    justify-content: center; /* İkonu butonun merkezine yerleştirmek için */
    align-items: center; /* Dikey olarak hizalamak için */
}

#popup_box , #acil_popup_box{
    background-color: transparent;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    padding: 30px;
    z-index: 9999;
    width: 25%; /* Set the width to make it narrower */
    height: 25%;
    border: none;
}

#overlay { 
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    backdrop-filter: blur(5px);
    z-index: 9998; /* Popup'ın hemen altında */
}

#yes_button {
    background: green;
    color: white;
    margin: 10px;
    letter-spacing:2pt;
    padding:15px 30px;
    font-family: 'Oswald', sans-serif;
    font-size: 1.2rem;
    border-radius: 25px;
    cursor:pointer;
    transition: background-color 0.3s ease; 
}

#no_button {
    background: red;
    color: white;
    margin: 10px;
    letter-spacing:2pt;
    padding:15px 30px;
    font-family: 'Oswald', sans-serif;
    border-radius: 25px;
    cursor:pointer;
    transition: background-color 0.3s ease;
}

#popup_text {
    text-align: center;
    font-family: 'Oswald', sans-serif;
    font-size: 1.5rem;
    letter-spacing:2pt;
    margin-bottom: 20px
}

#acil_popup_text{
    background: red;
    color: red;
    text-align: center;
    font-family: 'Oswald', sans-serif;
    font-size: 2rem;
    letter-spacing: 2pt;
    margin: 20px;
}

#yes_button:hover {
background-color: darkgreen; /* Buton üzerine gelindiğinde rengi koyulaştır */
}

#no_button:hover {
    background-color: darkred; /* Buton üzerine gelindiğinde rengi koyulaştır */
}
/* Custom defined classes for dradio elements*/

#toggle-barcode{
    display: flex;
    align-items: center;
    justify-content: left;
    padding: 10px;    
}

.tab-container button{
    font-size: 18px;
}

.svelte-s3jb61 p{
    font-size: 17px;
    font-weight: 600;
}

"""

# js 

js = """
    <script>
    function openFullscreen() {
        let elem = document.documentElement;

        if (elem.requestFullscreen) {
            elem.requestFullscreen();
        } else if (elem.mozRequestFullScreen) { // Firefox
            elem.mozRequestFullScreen();
        } else if (elem.webkitRequestFullscreen) { // Chrome, Safari and Opera
            elem.webkitRequestFullscreen();
        } else if (elem.msRequestFullscreen) { // IE/Edge
            elem.msRequestFullscreen();
        }
    }
    </script>
"""

######################### Global Functions #################

# update clock each second
def update_time():
    # Anlık saat, dakika ve saniye bilgisini döndüren fonksiyon
    return datetime.now().strftime("%H:%M:%S")

######################### SQL mock up Class #################

# class sql:
#     def __init__(self):
#         self.col_list = ['Operation_Date', 'Cabinet_No', 'Item_No', 'Message', 'User_Name']
    
#     def initialize_db(self):
#         # Define the database file path
#         db_path = os.path.join('Ayarlar', 'mockup_db.db')
        
#         # Check if the database file exists
#         if not os.path.isfile(db_path):
#             connection = sqlite3.connect(db_path)
#             cursor = connection.cursor()

#             # Create the table if it doesn't exist
#             cursor.execute('''
#                 CREATE TABLE IF NOT EXISTS Cabinet_log_table(
#                     id INTEGER PRIMARY KEY AUTOINCREMENT,
#                     Operation_Date REAL NOT NULL,
#                     Cabinet_No INTEGER NOT NULL,
#                     Item_No TEXT NOT NULL,
#                     Message TEXT NOT NULL,
#                     User_Name TEXT NOT NULL
#                 )
#             ''')

#             # Read data from Excel and insert into the table
#             df = pd.read_excel('Ayarlar/DOLUP/Logs_638689311437868359.xlsx')

#             # Ensure the column names match exactly
#             columns = ", ".join(self.col_list)
#             placeholders = ", ".join(["?" for _ in self.col_list])

#             # Insert each row into the database
#             for index, row in df.iterrows():
#                 print(f"Inserting row {index}")  # Debugging output
#                 cursor.execute(f'''
#                     INSERT INTO Cabinet_log_table ({columns}) VALUES ({placeholders})
#                 ''', tuple([row[col_name] for col_name in self.col_list]))

#             connection.commit()  # Commit changes to the database
#             connection.close()   # Close the connection
#             print("Database initialized and data inserted.")
#         else:
#             print("Database already exists. Skipping initialization.")
        
#     def push_data(self, insert_list):
#         connection = sqlite3.connect('Ayarlar/mockup_db.db')
#         cursor = connection.cursor()

#         # Prepare the SQL query
#         columns = ", ".join(self.col_list)
#         placeholders = ", ".join(["?" for _ in self.col_list])

#         # Insert data into the table
#         cursor.execute(f'''
#             INSERT INTO Cabinet_log_table ({columns}) VALUES ({placeholders})
#         ''', tuple(insert_list))

#         connection.commit()  # Commit the transaction
#         connection.close()   # Close the connection
#         print(f"Inserted: {insert_list}")

#     def get_data(self):
#         connection = sqlite3.connect('Ayarlar/mockup_db.db')
#         cursor = connection.cursor()

#         # Get column names from the table
#         cursor.execute('PRAGMA table_info(Cabinet_log_table)')
#         columns_info = cursor.fetchall()
#         columns = [col[1] for col in columns_info]  # Extract column names

#         # Retrieve all data from the table
#         cursor.execute('SELECT * FROM Cabinet_log_table')
#         results = cursor.fetchall()
#         connection.close()

#         # Convert results to DataFrame
#         df = pd.DataFrame(results, columns=columns)
        
#         return df 

######################### GET, POST functions ###############
BASE_URL = "http://127.0.0.1:8000"

# sample data that will be posted to products
sample_product = {
    "urun_kodu": "1",
    "urun_adi": "KART1",
    "barkod_no": "123",
    "birimi": "IN",
    "skt": "2024-12-10",
    "sgt": "2025-01-01",
    "ms_level": 2,
    "package": "FIRIN",
    "thickness": 3.0
}

def post_to_product(product):
    try:
        # Send a POST request to /receive_data
        response = requests.post(f"{BASE_URL}/receive_data", json=product)
        if response.status_code == 200:
            print("Product added successfully:", response.json())
        else:
            print(f"Error: {response.status_code}, {response.text}")
    
    except requests.exceptions.RequestException as e:
        print(f"Error in request: {e}")

# Function to get data from /product
def get_receive_data():
    try:
        # Send a GET request to /product
        response = requests.get(f"{BASE_URL}/product/123")
        
        # Check if the request was successful
        if response.status_code == 200:
            data = response.json()
            print("Received Data:", json.dumps(data, indent=4))
            return data
        else:
            print(f"Error: {response.status_code}, {response.text}")
            return sample_product
    
    except requests.exceptions.RequestException as e:
        print(f"Error in request: {e}")
        return sample_product

######################### UI Class ##########################

class UserInterface:
    def createUI(self):
        # Gradio arayüzü oluşturuluyor.
        with gr.Blocks(fill_width="100", css=css, head=js, title="DOLUP") as app:
            gr.HTML("""
            <div id="header_row">
                <div class="header_title">
                    MSL TAKİP VE KONTROL PLATFORMU
                </div>
            </div>
                    
            <div class="header_hidden">
            </div>
                    
            <div class="footer">
                    ALL INFORMATION REGARDING THE PRODUCT BELONGS TO ILGEAI COMPANY ©
            </div>
            """)
            # Gozlebeyaz.png dosyasının yolunu base_dir kullanarak oluştur
            image_path = os.path.join(base_dir, 'Ayarlar/DOLUP/Dolup_Lacivert_1.png')

            # gr.Image bileşeninde dinamik yolu kullan
            gr.Image(image_path, elem_classes="logo-gozle", container=False, show_download_button=False, show_fullscreen_button=False)
            
            
            # ilgebeyaz.png dosyasının yolunu base_dir kullanarak oluştur
            ilgebeyaz_image_path = os.path.join(base_dir, "Ayarlar", "ilgebeyaz.png")

            # gr.Image bileşeninde dinamik yolu kullan
            gr.Image(ilgebeyaz_image_path, elem_classes="logo-ilge", container=False, show_download_button=False, show_fullscreen_button=False)
            
            with gr.Blocks() as main_block:
                # Create main tabs 
                with gr.Tab("Dashboard"):
                    gr.Markdown("### Dashboard tab")
                    
                with gr.Tab("Cabinet Editor"):
                    gr.Markdown("### Cabinet Editor tab")
                
                
                # get, post click event functions
                def get_data():
                    return pd.DataFrame([get_receive_data()])
                
                with gr.Tab("Stock"):
                    with gr.Row():
                        with gr.Row():
                            dropdown1 = gr.Dropdown(container=False, choices=["Option A", "Option B", "Option C"], value='Option A', show_label=False, interactive=True)
                            dropdown2 = gr.Dropdown(container=False, choices=["Option X", "Option Y", "Option Z"], value='Option X', show_label=False,  interactive=True)
                        
                        with gr.Row():
                            search_bar = gr.Textbox(container=False, show_label=False, placeholder="Type your query...")
                        
                        with gr.Row():
                            toggle_switch = gr.Checkbox(container=False, label=f"Barcode status", value=False, elem_id='toggle-barcode', min_width=(60, 65))
                        
                        with gr.Row():
                            get_button = gr.Button("GET", min_width=70, size='lg')
                            post_botton = gr.Button("POST", min_width=70, size='lg')
                        
                        with gr.Row():
                            button2 = gr.Button("Export", min_width=70, size='lg')
                    
                    
                    with gr.Blocks() as data_frame:
                        # Define the interface
                        table = gr.Dataframe(value=pd.DataFrame([sample_product]), label="Incomming Server Data", elem_id='data_frame')
                    get_button.click(fn=get_data, outputs=table)
                with gr.Tab("Help"):
                    gr.Markdown("### Help tab")
                    
            
            # Dijital saati 1 sn de 1 update ederek gösterir
            gr.HTML("<div style='flex: 1; height:310px;'></div>")  # Üstteki öğeler ile zaman göstergesinin arasına boşluk ekler.
            time_display = gr.Label(update_time(), elem_classes="time-display", container=False)  # Canlı zaman gösterimi
            timer = gr.Timer(value=1, active=True)  # Zamanı her saniye günceller.
            timer.tick(fn=update_time, outputs=time_display)
                
        
        # Oswald.ttf ve DSFONT.ttf dosyalarının yolunu base_dir kullanarak oluştur
        allowed_paths = [
            os.path.join(base_dir, "Ayarlar", "Oswald.ttf"),
            os.path.join(base_dir, "Ayarlar", "DSFONT.ttf")
        ]

        # SadeceLogo.png dosyasının yolunu base_dir kullanarak oluştur
        favicon_path = os.path.join(base_dir, "Ayarlar", "SadeceLogo.png")

        # app.launch fonksiyonunda dinamik yolları kullan
        app.launch(allowed_paths=allowed_paths, inbrowser=True, favicon_path=favicon_path)

def get_uuid(): 
    try:
        result = subprocess.run(['blkid', '-s', 'UUID', '-o', 'value', '/dev/nvme0n1p2'], capture_output=True, text=True, check=True)
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        print(f"Hata: {e}")
        return None

ui = UserInterface()
ui.createUI()

