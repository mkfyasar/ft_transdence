import psycopg2
from psycopg2.extras import RealDictCursor

db_config = {
    "host": "localhost",
    "database": "erpdb",
    "user":"ilge",
    "password":"123",
    "port":"5432"
}

def create_users_table():
    try:
        conn = psycopg2.connect(**db_config)
        cursor = conn.cursor()
        
        table_name = "users_db"  
        
        cursor.execute(f"""
            SELECT EXISTS (
                SELECT FROM information_schema.tables
                WHERE table_name = '{table_name}'
            );
        """)
        
        table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            print("Tablo Bulunamadı.!!!")
            
            create_table_query = f"""
            CREATE TABLE {table_name}(
                id SERIAL PRIMARY KEY,
                username VARCHAR(50) UNIQUE,
                password TEXT,
                title TEXT,
                position TEXT,
                mail TEXT,
                status TEXT
            );
            """
            cursor.execute(create_table_query)
            conn.commit()
            print(f"Tablo '{table_name}' oluşturuldu")
        else:
            print(f"Tablo '{table_name}' zaten mevcut")
    except Exception as e:
        print(f"Tablo oluşturulurken hata oluştu: {e}")
    finally:
        cursor.close()
        conn.close()

create_users_table()