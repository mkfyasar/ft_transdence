import os
import json
import time
import sqlite3
import requests
import subprocess
import pandas as pd
import gradio as gr
from datetime import datetime

base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)))

################# base css codes for UI #####################
css = """
@font-face {
    font-family: 'Oswald';
    src: url('/file=Ayarlar/Oswald.ttf') format('truetype');
}

@font-face {
    font-family: 'DS-DIGIB';
    src: url('Ayarlar/DS-DIGIB.TTF') format('truetype');
}
.info-box {
    padding: 10px;
    border: 1px gray solid;
    border-radius: 10px;
}

.time-display h2 {
    font-family: 'DS-DIGIB', sans-serif;
    font-size: 30pt;
    color: white;
    position: fixed;
    bottom: 0.6%;
    left: 2%;   
    z-index: 2000;
    padding: 0;
    margin-top: auto; /* En alta itilmesini sağlar */
}

.logo-gozle {
    display: flex;
    justify-content: flex-start;
    position: fixed;
    top: -15px;
    left: -15px;
    z-index: 1500;
    padding: 0;
    width: 21%;
    height: 10%;
}

.logo-ilge {
    display: flex;
    justify-content: flex-end;
    position: fixed;
    bottom: 2%;
    right: 2%;
    z-index: 1500;
    padding: 0;
    width: 21%;
    height: 3%;
}

.header_hidden{
    position: relative;
    margin-top: 3%;
}

.footer_hidden {
    height: 10%;
}

.footer_title_hidden {
    font-size: 11pt;
}

.start-button, .stop-button {
    border: none;
    color: #ffffff;
    font-weight: bold;
    font-family: 'Oswald', sans-serif;
    font-size: 20pt;
    cursor: pointer;
}

.run-button img {
    width: 60px;  /* İkonun genişliğini ayarlayın */
    height: 60px; /* İkonun yüksekliğini ayarlayın */
}

#process-container {
    display: flex;
    justify-content: space-between;
    padding: 10px 50px 30px 50px;
}

.good-product-display h2 {
    font-family: 'Oswald', sans-serif;
    font-size: 30pt;
    color: green;
    position: relative; /* Konumlandırma */
    padding-top: 10;
    margin-top: auto; /* En alta itilmesini sağlar */
}

.defective-product-display h2 {
    font-family: 'Oswald', sans-serif;
    font-size: 30pt;
    color: red;
    position: relative; /* Konumlandırma */
    padding-top: 10;
    margin-top: auto; /* En alta itilmesini sağlar */
}

.total-product-display h2 {
    font-family: 'Oswald', sans-serif;
    font-size: 30pt;
    color: white;
    position: relative; /* Konumlandırma */
    padding-top: 10;
    margin-top: auto; /* En alta itilmesini sağlar */
}
.efficiency-display h2 {
    font-family: 'Oswald', sans-serif;
    font-size: 30pt;
    color: cyan;
    position: relative; /* Konumlandırma */
    padding-top: 10;
    margin-top: auto; /* En alta itilmesini sağlar */
}

#header_row {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    background-color: #003366;
    margin-left: 0;
    position: fixed;
    top: 0;
    left: 0;
    height: 7%;
    width: 100%;
    box-shadow: 0 -2px 5px rgba(0,0,0,0.2);
    z-index: 1000;
}

.header_title {
    display: flex;
    align-items: center;
    height: 100%;
    justify-content: center;
    font-family: 'Oswald', sans-serif;
    font-size: 2vw;
    letter-spacing: 2px;
    font-weight: bold;
    text-align: center;
    margin-left: 10px;
    width: 100%;
    color: #fff;
    padding: 10px;
}

.footer {
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #003366;
    color: #fff;
    font-size: 13pt;
    text-align: center;
    padding: 10px 20px;
    position: fixed;
    bottom: 0;
    left: 0;
    height: 7%;
    width: 100%;
    box-shadow: 0 -2px 5px rgba(0,0,0,0.2);
    z-index: 1000;
}

.content {
    margin-top: 80px; /* Header'ın altında boşluk bırakır */
    margin-bottom: 50px;
    display: flex;
    flex-direction: row;
}

.left-column {
    display: flex;
    flex-direction: column;
    justify-content: space-between;  /* Zaman göstergesini en alta iter */
    width: 25%;
    height: 100vh; /* Yüksekliği tüm görünüm alanını kaplayacak şekilde ayarlar */
}

.right-column {
    display: flex;
    
    flex-direction: column;
    width: 75%;
}

.logo-genel {
    padding: 0;
    margin: 0;
    flex: 0 0 auto;
    min-width: 40px;  /* Minimum genişliği ayarlıyoruz */
    max-width: 40px;  /* Maksimum genişliği ayarlıyoruz */
    flex-shrink: 1;   /* Container'ın küçülmesini sağlıyoruz */
}

.logo-genel img {
    width: 40px;  /* Resim boyutunu sabitliyoruz */
    height: 40px;
    margin: 0;
    padding: 0;
}

#icons {
    position: fixed;
    justify-content: flex-end;  /* Resimleri sağa yaslamak için */
    top: 1.5%;
    right: 2%;
    display: flex;
    flex-direction: row;  /* Resimleri yatay olarak hizalıyoruz */
    align-items: center;
    z-index: 1500;
    width: 20%; /* Butonların toplam genişliği kapsayıcıdan taşmayacak */
    padding: 0;
    margin: 0;
}

#icons img {
    width: 30px;  /* İkonun genişliğini ayarlayın */
    height: 30px; /* İkonun yüksekliğini ayarlayın */
}

.header-buttons {
    background: transparent;
    padding: 0;
    margin: 0 5px; /* Butonlar arasında boşluk bırakmak için */
    border: none;
    flex: 0 0 auto; /* Butonların genişliğini ikon boyutuna göre ayarlayın */
    width: 40px; /* İsteğe bağlı: Buton genişliğini manuel olarak ayarlayın */
    height: 40px; /* İsteğe bağlı: Buton yüksekliğini manuel olarak ayarlayın */
    display: flex; /* Buton içindeki içeriği flex ile hizalamak için */
    justify-content: center; /* İkonu butonun merkezine yerleştirmek için */
    align-items: center; /* Dikey olarak hizalamak için */
}

.motor-buttons {
    background: transparent;
    padding: 0;
    margin: 0 5px; /* Butonlar arasında boşluk bırakmak için */
    border: none;
    flex: 0 0 auto; /* Butonların genişliğini ikon boyutuna göre ayarlayın */
    width: 40px; /* İsteğe bağlı: Buton genişliğini manuel olarak ayarlayın */
    height: 40px; /* İsteğe bağlı: Buton yüksekliğini manuel olarak ayarlayın */
    display: flex; /* Buton içindeki içeriği flex ile hizalamak için */
    justify-content: center; /* İkonu butonun merkezine yerleştirmek için */
    align-items: center; /* Dikey olarak hizalamak için */
}

#popup_box , #acil_popup_box{
    background-color: transparent;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    padding: 30px;
    z-index: 9999;
    width: 25%; /* Set the width to make it narrower */
    height: 25%;
    border: none;
}

#overlay { 
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    backdrop-filter: blur(5px);
    z-index: 9998; /* Popup'ın hemen altında */
}

#yes_button {
    background: green;
    color: white;
    margin: 10px;
    letter-spacing:2pt;
    padding:15px 30px;
    font-family: 'Oswald', sans-serif;
    font-size: 1.2rem;
    border-radius: 25px;
    cursor:pointer;
    transition: background-color 0.3s ease; 
}

#no_button {
    background: red;
    color: white;
    margin: 10px;
    letter-spacing:2pt;
    padding:15px 30px;
    font-family: 'Oswald', sans-serif;
    border-radius: 25px;
    cursor:pointer;
    transition: background-color 0.3s ease;
}

#popup_text {
    text-align: center;
    font-family: 'Oswald', sans-serif;
    font-size: 1.5rem;
    letter-spacing:2pt;
    margin-bottom: 20px
}

#acil_popup_text{
    background: red;
    color: red;
    text-align: center;
    font-family: 'Oswald', sans-serif;
    font-size: 2rem;
    letter-spacing: 2pt;
    margin: 20px;
}

#yes_button:hover {
background-color: darkgreen; /* Buton üzerine gelindiğinde rengi koyulaştır */
}

#no_button:hover {
    background-color: darkred; /* Buton üzerine gelindiğinde rengi koyulaştır */
}
/* Custom defined classes for dradio elements*/

#toggle-barcode{
    display: flex;
    align-items: center;
    justify-content: left;
    padding: 5px;   
}

.tab-container button{
    font-size: 18px;
}

.svelte-s3jb61 p{
    font-size: 17px;
    font-weight: 600;
}

#setting-block{
    background: #18181b;
    margin-top: 20px;
}
#float-div,
#login-float-div{
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: rgba(0, 51, 102, 1);
    color: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    font-family: 'Arial', sans-serif;
    z-index: 1000;
    width: 900px;
    max-width: 90%;
    text-align: left;
    animation: fadeIn 0.2s ease-in-out;
}

#login-float-div{
    width: 400px;
}


#float-div .gr-dropdown {
    position: relative;
    z-index: 2000;
    width: 100%;
}

#float-div .gr-dropdown .dropdown-menu {
    position: absolute;
    top: 100%;
    left: 0;
    background-color: white;
    color: black;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    min-width: 100%;
    display: none;
}

#float-div .gr-dropdown:hover .dropdown-menu {
    display: block;
}

/* Close button (X mark) */
#close-btn {
    position: absolute;
    text-align: center;
    top: 7px;
    right: 7px;

    background: #52525b;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    border: none;
    font-size: 14px;
    cursor: pointer;
    z-index: 2001;
}

#logIn-header {
    font-size: 24px;  
    font-weight: bold;
    text-align: center;
}

.user-details {
    font-size: 20px; 
    color: #333; 
    margin: 10px;
    max-width: 400px; 
}

.user-row {
    display: flex; 
    justify-content: space-between;
    margin: 8px 0;
}

.field-name {
    font-weight: bold; 
    width: 40%; 
    text-align: left; 
}

.field-value {
    width: 60%; 
    text-align: left; 
}

#user-foto .prose{
    display: flex;
    justify-content: center;
    align-items: center;
}

#username-div{
    background-color: rgba(0, 51, 102, 1);
}

/* Fade-in effect */
.cabinet-container {
    display: flex;
    flex-wrap: wrap;    
    gap: 20px;
}

.cabinet:hover{
    cursor: pointer;
}

.cabinet {
    width: 100px;
    height: 200px;
    border: 2px solid black;
    border-radius: 5px;
    display: flex;
    flex-direction: row;
    background-color: #f9f9f9;
    box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
}


.cabinet:hover{
    cursor: pointer;
}

.cabinet .left-panel {
    width: 20%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.cabinet .left-panel .handle {
    width: 5px;
    height: 40px;
    background-color: white;
    border-radius: 2px;
}

.cabinet .right-panel {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 5px;
    padding: 5px;
}

.cabinet.type-1 {
    border-color: #0077ff;
    background-image: linear-gradient(to bottom, #e0f7ff, #b3eaff);
}

.cabinet.type-1 .left-panel {
    background-color: #0077ff;
}

.cabinet.type-1 .right-panel {
    background-image: radial-gradient(circle, #ffffff, #cce7ff);
}

.cabinet.type-1 .right-panel .door {
    flex: 1;
    background-color: #80d4ff;
    border: 1px solid #0077ff;
    border-radius: 5px;
}

.cabinet.type-2 {
    border-color: #ff6600;
    background-image: linear-gradient(to bottom, #ffe0cc, #ffb399);
}

.cabinet.type-2 .left-panel {
    background-color: #ff6600;
}

.cabinet.type-2 .right-panel {
    background-color: #ff9966;
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 5px;
}

.cabinet.type-2 .right-panel .door {
    background-color: #ffcc99;
    border: 2px dashed #ff6600;
    border-radius: 5px;
}

.cabinet.type-3 {
    border-color: #333333;
    background-image: linear-gradient(to bottom, #cccccc, #999999);
}

.cabinet.type-3 .left-panel {
    background-color: #666666;
}

.cabinet.type-3 .right-panel {
    background-color: #b3b3b3;
    display: flex;
    flex-direction: column;
    gap: 5px;
    align-items: center;
}

.cabinet.type-3 .right-panel .door {
    width: 80%;
    height: 20px;
    background-color: #999999;
    border: 1px solid #666666;
    border-radius: 3px;
}

.cabinet-label {
    text-align: center;
    font-size: 14px;
    font-weight: bold;
    margin-top: 5px;
}

#add-cabinet-btn{
    width: 200px;
}

#add-del-btn-container{
    display: flex;
    justify-content: flex-end;
}

#add-user-btn {
    max-width: 160px;
    align-item: left;
}

#toggle-barcode {
    transform: scale(1.2);
    transform-origin: left center;
}


/* Fade-in effect */
@keyframes fadeIn {
    0% {
        opacity: 0;
    }
    100% {
        opacity: 1;
    }
}


"""

# js 


js = """
    <script>
        function openFullscreen() {
            let elem = document.documentElement;

            if (elem.requestFullscreen) {
                elem.requestFullscreen();
            } else if (elem.mozRequestFullScreen) { // Firefox
                elem.mozRequestFullScreen();
            } else if (elem.webkitRequestFullscreen) { // Chrome, Safari and Opera
                elem.webkitRequestFullscreen();
            } else if (elem.msRequestFullscreen) { // IE/Edge
                elem.msRequestFullscreen();
            }
        }
    </script>
"""
######################### Global Functions #################

# update clock each second
def update_time():
    # Anlık saat, dakika ve saniye bilgisini döndüren fonksiyon
    return datetime.now().strftime("%H:%M:%S")

######################## Global Variables ###################

BASE_URL = "http://192.168.1.111:8000/"
user_type = 'admin'
logIn_user_name = 'mehmet7'
barcode_data = {}
is_in_stock = False
is_read_on = False
is_del_on = False
######################### GET, POST functions ###############


# sample data that will be posted to products
sample_product = {
      "material_id": "9njE9wm1",
      "state": "lt8sg5zK",
      "progress": "0BSKjAfs",
      "manufacturer": "Xh2o3Ckl",
      "package": "123",
      "ms_level": "H7d93LmQ",
      "quantity": "42",
      "thickness": "5.72",
      "register_time": "2023-08-15 14:23:11",
      "last_processing_time": "2023-12-01 18:12:05",
      "outside_time_at_floor": "2023-09-10 08:45:30",
      "time_in_cabinet": "2023-11-05 10:12:14",
      "location": "RqkP9b3M",
      "status": "active",
      "expiration_date": "2024-07-19 00:00:00"
    }

def post_to_product(product):
    try:
        # Send a POST request to /receive_data
        response = requests.post(f"{BASE_URL}/post_stock", json=product)
        if response.status_code == 200:
            print("Product added successfully:", response.json())
        else:
            print(f"Error: {response.status_code}, {response.text}")
    
    except requests.exceptions.RequestException as e:
        print(f"Error in request: {e}")

# Function to get data from /product
def api_get(table_name):
    try:
        # Send a GET request to /product
        response = requests.get(f"{BASE_URL}/{table_name}")
        
        # Check if the request was successful
        if response.status_code == 200:
            data = response.json()
            print("Received Data:", json.dumps(data, indent=4))
            return data
        else:
            print(f"Error: {response.status_code}, {response.text}")
            return sample_product
    
    except requests.exceptions.RequestException as e:
        print(f"Error in request: {e}")
        return   
    
def request_login(username, password):
    global logIn_user_name
    try:
        response = requests.post(f"{BASE_URL}/login?username={username}&password={password}")
        
        if response.status_code == 200:
            print(response.text)
            logIn_user_name = username
            return response.json()
        
        elif response.status_code == 404:
            return 'u'
        
        else: 
            return 'p'
    
    except requests.exceptions.RequestException as e:
        pass

def api_post(post_query):
    try:
        response = requests.post(f"{BASE_URL}{post_query}")
        
        if response.status_code == 200:
            print(response.text)
            return response.json()
        
        elif response.status_code == 404:
            return 'u'
        
        else: 
            return 'p'
    
    except requests.exceptions.RequestException as e:
        pass

def get_username(username):
    try:
        response = requests.get(f"{BASE_URL}get_user/{username}")
        
        if response.status_code == 200:
            return response.json()
        
        else: 
            return response.json()
    
    except requests.exceptions.RequestException as e:
        return {'error': 'exceptional Err'}
        


# check user in database and add user to the database
def checkNadd_user_to_db(username, password='123', title='operator', position='Shelf Operator', mail='example@gmail.com', status='Active'):
    check_users = get_username(username)
    
    if check_users.get('user', None) == None:
        try:
            response = requests.post(f"{BASE_URL}/add_user?username={username}&password={password}&title={title}&position={position}&mail={mail}&status={status}")
            
            if response.status_code == 200:
                print(response.text)
                return response.json()
            
            elif response.status_code == 422:
                return 'error'
        
        except requests.exceptions.RequestException as e:
            pass
    else: 
        return 'exist'
    
# check user in database and delete user from the database
def checkNdelete_user_from_db(username):
    check_users = get_username(username)
    
    if check_users.get('user', None) == None:
        return 'not exist'
    
    else: 
        try:
            response = requests.delete(f"{BASE_URL}/delete_user?username={username}")
            
            if response.status_code == 200:
                print(response.text)
                return response.json()
            
            elif response.status_code == 422:
                return 'error'
        
        except requests.exceptions.RequestException as e:
            pass

######################### UI Class ##########################

class UserInterface:
    def createUI(self):
        # Gradio arayüzü oluşturuluyor.
        with gr.Blocks(fill_width="100", css=css, head=js, title="DOLUP") as app:
            gr.HTML("""
            <div id="header_row">
                <div class="header_title">
                    MSD TRACKING AND CONTROL PLATFORM
                </div>
            </div>
                    
            <div class="header_hidden">
            </div>
                    
            <div class="footer">
                    ALL INFORMATION REGARDING THE PRODUCT BELONGS TO ILGEAI COMPANY ©
            </div>
            """)
            
            
            # Gozlebeyaz.png dosyasının yolunu base_dir kullanarak oluştur
            image_path = os.path.join(base_dir, 'Ayarlar/DOLUP/Dolup_Lacivert_1.png')

            # gr.Image bileşeninde dinamik yolu kullan
            gr.Image(image_path, elem_classes="logo-gozle", container=False, show_download_button=False, show_fullscreen_button=False)
            
            
            # ilgebeyaz.png dosyasının yolunu base_dir kullanarak oluştur
            ilgebeyaz_image_path = os.path.join(base_dir, "Ayarlar", "ilgebeyaz.png")

            # gr.Image bileşeninde dinamik yolu kullan
            gr.Image(ilgebeyaz_image_path, elem_classes="logo-ilge", container=False, show_download_button=False, show_fullscreen_button=False)
            
            def handle_login(username, password):
                return gr.update(visible=False), gr.update(visible=True), gr.update(visible=False)
                login_respond = request_login(username, password)       
                if isinstance(login_respond, dict):
                    if login_respond['title'] == 'superuser':
                        pass
                    
                    elif login_respond["title"] == 'admin':
                        pass
                    
                    elif login_respond['title'] == 'chef':
                        pass
                    
                    else:
                        pass
                    
                return gr.update(visible=True), gr.update(visible=False), gr.update(visible=True, value=f"<div>{'Incorrect Username' if username != 'admin' else 'Incorrect Password'}<div/>")
                
            with gr.Row(elem_id='login-float-div') as login_pop_up:
                with gr.Column(scale=2):
                    gr.HTML("""
                            <div id='logIn-header'>Log In<div/>
                            """)
                    user_name = gr.Textbox(label="User Name", interactive=True, elem_id='username-div', container=False, placeholder='Username')
                    password = gr.Textbox(label="Password", interactive=True, elem_id='username-div', container=False, placeholder='password')
                    login_status = gr.HTML("""
                            <div><div/>
                            """, visible=False)
                    login_btn = gr.Button('Sign In')  
            
            with gr.Tabs(visible=False) as main_block:
                # Create main tabs 
                with gr.Tab("Dashboard"):
                    gr.Markdown('dashBoard', render=False)
                    
                with gr.Tab("Cabinet Editor"):
                    def update_row_colors(row_index, column_index, color1, current_colors, columns_count):
                        row_index = int(row_index) - 1
                        column_index = int(column_index) - 1

                        current_colors[row_index][column_index] = (color1) 
                        updated_html = update_cabinet_layout(columns_count, current_colors)
                        return updated_html, current_colors

                    def update_cabinet_layout(columns_count, current_colors=None):
                        rows = []

                        for i in range(12):
                            row_html = "<div style='display: flex; flex-direction: row; margin-bottom: 10px;'>"
                            for j in range(columns_count):
                                color1= current_colors[i][j] if current_colors else ("#ce6400") 
                                row_html += f"""
                                <div style='flex: 1; height: 30px; border-radius: 7px; border: 2px solid #ddd; margin: 0 3px 0 3px; padding: 3px; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); background: linear-gradient(to bottom, #f9f9f9, #e9e9e9);'>
                                    <div style='height: 70; background-color: {color1}; margin-bottom: 2px; border-radius: 4px;'></div>
                                </div>
                                """
                            row_html += "</div>"
                            rows.append(row_html)

                        return "".join(rows)

                    def move_second_to_first(current_colors):
                        # Move the second column to the first column and clear the second column
                        for row in current_colors:
                            if len(row) > 1:  # Ensure there is a second column
                                row[0] = row[1]  # Copy second column to first column
                                row[1] = ("#ffffff")  # Clear the second column (set to white)
                        return current_colors

                    default_colors = [[("#ce6400")] * 4 for _ in range(12)]

                    with gr.Blocks() as ui:
                        with gr.Row():
                            with gr.Column(scale=1):
                                gr.Markdown("### Cabinet", elem_id="cabinet-title")
                                cabinet_display = gr.HTML(update_cabinet_layout(4, default_colors), elem_id="cabinet")

                            # with gr.Column(scale=1):
                            #     gr.Markdown("### Controls")
                            #     row_index = gr.Dropdown(choices=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], label="Row Index")
                            #     column_index = gr.Dropdown(choices=[1, 2, 3, 4], label="Column Index")
                            #     color_picker1 = gr.ColorPicker(label="Larger Div Color")  
                            #     color_picker2 = gr.ColorPicker(label="Smaller Div Color") 
                            #     current_colors = gr.State(value=default_colors)
                            #     update_button = gr.Button("Update Row Color")

                            #     column_count_dd = gr.Dropdown(choices=[1, 2, 3, 4], label="Column Count")

                            #     column_count_dd.change(
                            #         fn=update_cabinet_layout,
                            #         inputs=[column_count_dd, current_colors],
                            #         outputs=[cabinet_display],
                            #     )

                                # update_button.click(
                                #     update_row_colors,
                                #     inputs=[row_index, column_index, color_picker1, color_picker2, current_colors, column_count_dd],
                                #     outputs=[cabinet_display, current_colors],
                                # )

                                # move_button = gr.Button("Move Second Column to First")

                                # move_button.click(
                                #     fn=lambda colors: (update_cabinet_layout(4, move_second_to_first(colors)), move_second_to_first(colors)),
                                #     inputs=[current_colors],
                                #     outputs=[cabinet_display, current_colors],
                                # )

                            with gr.Column(scale=2):
                                gr.Markdown("### Cabinet Status")
                                with gr.Row(elem_id='float-div', visible=False) as cabinet_selection_pop_up:
                                    # Left Panel
                                    with gr.Column(scale=1):
                                        cabinet_types = gr.Dropdown(['Moisture', 'Baking', 'Solder Paste'], label="Cabinet Type", interactive=True, filterable=False)
                                        cabinet_name = gr.Textbox(label="Cabinet Name", interactive=True)
                                        temp = gr.Dropdown(['40 °C', '60 °C', '90 °C', '125 °C'], label="Temperature", interactive=True, filterable=False)
                                        with gr.Column():
                                            with gr.Row():
                                                row_number = gr.Number(label="Rows", interactive=True, minimum=1, maximum=100)
                                                col_number = gr.Number(label="Columns", interactive=True, minimum=1, maximum=100)
                                                cabinet_save_button = gr.Button("Save", elem_classes="save-btn")
                                    
                                    cabinet_close_button = gr.Button("X", elem_id="close-btn", min_width=2,)
                                    
                                    def cabinet_pop_up_close():
                                        return gr.update(visible=False)
                        
                                    cabinet_close_button.click(fn=cabinet_pop_up_close, outputs=[cabinet_selection_pop_up])
                                    

                                with gr.Column() as show_cabinets:
                                    with gr.Column():
                                        add_cabinet = gr.Button('➕ Add Cabinet', elem_id='add-cabinet-btn', min_width=5)
                                        cabinet_html = gr.HTML("""
                                                            <div>
                                                                <div class="cabinet-container">
                                                                </div>
                                                            </div>
                                        """, label="Cabinets Display")

                                        
                                        def show_pop_up():
                                            return gr.update(visible=True)
                                        
                                        add_cabinet.click(fn=show_pop_up, outputs=[cabinet_selection_pop_up])
                                
                                def handle_cabinet_change(type, name, temp, cabinet_html):
                                    type_p_h = ''

                                    active_p_h = 'Active' if name else 'Inactive'
                                    
                                    type_1 = f'''
                                            <div>
                                                <div class="active-status" style="text-align: center; background: {'#2ea65a' if name else '#8b2b01'}; border-radius: 5px; margin-bottom: 10px;">{active_p_h}</div>
                                                <div class="cabinet type-1">
                                                    <div class="left-panel">
                                                        <div class="handle"></div>
                                                    </div>
                                                    <div class="right-panel">
                                                        <div class="door"></div>
                                                        <div class="door"></div>
                                                        <div class="door"></div>
                                                        <div class="door"></div>
                                                    </div>
                                                </div>
                                                <div class="cabinet-label">Moisture Cabinet</div>
                                                <div class="cabinet-label">{name}</div>
                                            </div>
                                            '''
                                            
                                    type_2 = f'''
                                            <div>
                                                <div class="active-status" style="text-align: center; background: {'#2ea65a' if name else '#8b2b01'}; border-radius: 5px; margin-bottom: 10px;">{active_p_h}</div>
                                                <div class="cabinet type-2">
                                                    <div class="left-panel">
                                                        <div class="handle"></div>
                                                    </div>
                                                    <div class="right-panel">
                                                        <div class="door"></div>
                                                        <div class="door"></div>
                                                        <div class="door"></div>
                                                        <div class="door"></div>
                                                    </div>
                                                </div>
                                                <div class="cabinet-label">Baking Cabinet</div>
                                                <div class="cabinet-label">{name}</div>
                                            </div>
                                            ''' 
                                    
                                    type_3 = f'''
                                            <div>
                                                <div class="active-status" style="text-align: center; background: {'#2ea65a' if name else '#8b2b01'}; border-radius: 5px; margin-bottom: 10px;">{active_p_h}</div>
                                                <div class="cabinet type-3">
                                                    <div class="left-panel">
                                                        <div class="handle"></div>
                                                    </div>
                                                    <div class="right-panel">
                                                        <div class="door"></div>
                                                        <div class="door"></div>
                                                        <div class="door"></div>
                                                        <div class="door"></div>    
                                                        <div class="door"></div>
                                                        <div class="door"></div>
                                                        <div class="door"></div>
                                                        <div class="door"></div>
                                                    </div>
                                                </div>
                                                <div class="cabinet-label">Solder Cabinet</div>
                                                <div class="cabinet-label">{name}</div>
                                            </div>
                                            '''
                                    if type == 'Moisture':
                                        type_p_h = type_1
                                    elif type == 'Baking':
                                        type_p_h = type_2
                                    elif type == 'Solder Paste':
                                        type_p_h = type_3
                                    container = f"""
                                                <div>
                                                    <div class="cabinet-container">
                                                    {type_p_h}
                                                    </div>
                                                </div>
                                                """
                                    return cabinet_html[:cabinet_html.find('<div class="cabinet-container">')+31] + type_p_h + cabinet_html[cabinet_html.find('<div class="cabinet-container">')+31:], gr.update(visible=False)
                                
                                cabinet_save_button.click(fn=handle_cabinet_change, 
                                                  inputs=[cabinet_types, cabinet_name, temp, cabinet_html], 
                                                  outputs=[cabinet_html, cabinet_selection_pop_up])
                                                       
                with gr.Tab("Stock"):
                    with gr.Row():
                        with gr.Row():
                            dropdown1 = gr.Dropdown(container=False, choices=["All Cabinets", "Cabinet 1", "Cabinet 2"], show_label=False,  interactive=True, value='All Cabinets')
                            dropdown2 = gr.Dropdown(container=False, choices=["List All Items", "List Waiting Items", "List Inside Items", "List Outside Items", "List Expired Items", "List Removed Components"], value='List All Items', show_label=False, interactive=True)
                        
                        with gr.Row():
                            search_bar = gr.Textbox(container=False, show_label=False, placeholder="Search by Barcodes")
                        
                        with gr.Row():
                            read_delete_toggle = gr.Radio(
                                choices=["Stock By Barcode", "Delete By Barcode"],
                                show_label=False,
                                container=False,
                                elem_id='toggle-barcode',
                                value="",
                                interactive=True)
                        
                        def handle_switch(toggle):
                            global is_read_on, is_del_on
                            if toggle == "Stock By Barcode":
                                is_read_on, is_del_on = True, False
                            elif toggle == "Delete By Barcode":
                                is_read_on, is_del_on = False, True
                            else:
                                is_read_on, is_del_on = False, False
                            return
                            
                        
                        read_delete_toggle.change(fn=handle_switch, inputs=[read_delete_toggle])
                        
                        
                        with gr.Row():
                            button2 = gr.Button("Search", min_width=70, size='lg')
                        
                        with gr.Row():
                            get_button = gr.Button("GET", min_width=70, size='lg')
                            post_botton = gr.Button("POST", min_width=70, size='lg')

                    with gr.Row(elem_id='float-div', visible=False) as query_pop_up:
                        with gr.Column(scale=2):
                            stock_code = gr.Textbox(label="Stock Code", interactive=True)
                            description = gr.Textbox(label="Description", interactive=True)
                            msd_barcode = gr.Textbox(label="MSD Barcode", interactive=True)
                            quantity = gr.Textbox(label="Quantity", interactive=True)
                            package = gr.Dropdown(["OTHERS", "PQFPS", "PLCCs", "MQFPS", "BGAs", "SOICs", "TQFPS", "TSOPs"], label="Package", interactive=True, filterable=False)
                            thickness = gr.Dropdown(["≥3.1 mm", "≥2.1 mm - <3.1mm", "<2.1mm"], label="Thickness", interactive=True, filterable=False)
                            ms_level = gr.Dropdown(["LEVEL 2A", "LEVEL 3", "LEVEL 4", "LEVEL 5", "LEVEL 5A",    ], label="Ms Level", interactive=True, filterable=False)
                            temp = gr.Dropdown(['40 °C', '60 °C', '90 °C', '125 °C'], label="Temperature", interactive=True, filterable=False)
                            with gr.Column():
                                location = gr.Dropdown(["Option 1", "Option 2"], label="Location", interactive=True, filterable=False)
                                with gr.Row():
                                    update_button = gr.Button("Update", elem_classes="update-btn")
                                    save_button = gr.Button("Save", elem_classes="save-btn")
                            
                            def handle_thickness_dropdown(pkg_type):
                                if pkg_type == 'BGAs':
                                    thickness_arr = ["> 1 mm body thickness","< 1 mm body thickness"]
                                                  
                                elif pkg_type == 'PLCCs':
                                    thickness_arr = ['Square', '18-32 Pins(Rectangular)']
  
                                elif pkg_type == 'PQFPS':
                                    thickness_arr = ['> 84 Pins', '< 80 Pins']
  
                                elif pkg_type == 'SOICs':
                                    thickness_arr = ['Wide Body', '> 20 Pins', '< 18 Pins']
  
                                else:
                                    thickness_arr = ["≥3.1 mm", "≥2.1 mm - <3.1mm", "<2.1mm"]
                                    
                                return gr.Dropdown(thickness_arr, label="Package", interactive=True, filterable=False, value=thickness_arr[0])
                                    
                            package.change(fn=handle_thickness_dropdown, inputs=[package], outputs=[thickness])
                    
                        # Close button
                        query_close_button = gr.Button("X", elem_id="close-btn", min_width=2,)
                    
                    with gr.Blocks() as stock_data_frame:
                        get_stock_data = pd.DataFrame(api_get('get_stocks')['stocks'])
                        get_stock_data.insert(0, 'id', range(1, len(get_stock_data)+1))
                        stock_table = gr.Dataframe(value=get_stock_data, 
                                                   column_widths=[70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70], 
                                                   wrap=True,label="Incomming Server Data", elem_id='data_frame')
                    
                    def query_pop_up_close():
                        return gr.Textbox(container=False, show_label=False, placeholder="Search by Barcodes", autofocus=True, value=''), gr.update(visible=False)
                    


                    query_close_button.click(fn=query_pop_up_close, outputs=[search_bar, query_pop_up])

                with gr.Tab("Settings", elem_id='setting-block'):
                    with gr.Tab("Users"):
                        with gr.Row(elem_id='float-div', visible=False) as add_user_pop_up:
                            # Left Panel
                            global user_type
                            with gr.Column(scale=1):
                                add_user_name = gr.Textbox(label='Username', interactive=True)
                                add_password = gr.Textbox(label='Password', interactive=True)
                                add_title = gr.Dropdown(choices=['Chef', 'Operator'] if user_type=='admin' else ['Chef', 'Operator', 'admin'], label="User Type", interactive=True, filterable=False)
                                add_position = gr.Textbox(label='Job Title', interactive=True)
                                add_mail = gr.Textbox(label="User Mail", interactive=True)
                                add_status = gr.Dropdown(['Active', 'Deactivate'], label="Active Status", interactive=True, filterable=False)
                                add_exist_status = gr.HTML('<div>User already exist in database.</div>', visible=False)
                                add_user_to_db = gr.Button("Add User", elem_classes="save-btn") # click listener @ #.1192
                            
                            add_close_button = gr.Button("X", elem_id="close-btn", min_width=2,)
                        
                        with gr.Row(elem_id='float-div', visible=False) as delete_user_pop_up:
                            # Left Panel
                            with gr.Column(scale=1):
                                delete_user_name = gr.Textbox(label='Username', interactive=True)
                                delete_exist_status = gr.HTML("<div>User doesn't exist in database.</div>", visible=False)
                                delete_user_from_db = gr.Button("Delete User", elem_classes="save-btn") # click listener @ #.1208
                            
                            delete_close_button = gr.Button("X", elem_id="close-btn", min_width=2,) 
                            
                        def admin_pop_up_close():
                            return gr.update(visible=False)
                        
                        delete_close_button.click(fn=admin_pop_up_close, outputs=[delete_user_pop_up])
                        add_close_button.click(fn=admin_pop_up_close, outputs=[add_user_pop_up])
                        
                        with gr.Row():
                            with gr.Column(scale=1, min_width=120, elem_id='user-foto'):  # Profile Section
                                gr.HTML('<div style="width:120px; height:150px; background:#d9d9d9; border-radius:8px;"></div>')
                            with gr.Column(scale=4):  # User Details
                                gr.HTML('''
                                        <div class="user-details">
                                            <div class="user-row">
                                                <span class="field-name">User ID</span>
                                                <span class="field-value">: admin</span>
                                            </div>
                                            <div class="user-row">
                                                <span class="field-name">Password</span>
                                                <span class="field-value">: ****</span>
                                            </div>
                                            <div class="user-row">
                                                <span class="field-name">Position</span>
                                                <span class="field-value">: Manager</span>
                                            </div>
                                            <div class="user-row">
                                                <span class="field-name">Mail</span>
                                                <span class="field-value">: mbr@xtreme.com</span>
                                            </div>
                                        </div> 
                                        ''')

                        # Authorizations Section
                        gr.Markdown("### Authorizations")
                        auth_table = gr.Dataframe(
                            headers=[
                                "User ID",
                                "Auth Level",
                                "Is Login Active",
                                "Is Mail Active",
                                "Is Special Limitations Active",
                                "Special Field",
                                "Auth Start Time",
                                "Auth End Time",
                            ],
                            value=[
                                [
                                    "admin",
                                    "Administrator",
                                    "✔",
                                    "✔",
                                    "",
                                    "*****",
                                    "21.03.2024",
                                    "20.05.2024",
                                ]
                            ],
                            interactive=False,
                        )

                        # Registered Users Section
                        with gr.Row():
                            gr.Markdown("### Registered Users")
                            with gr.Row(elem_id='add-del-btn-container') as add_del_btns:
                                add_user = gr.Button('➕ Add User', elem_id='add-user-btn',  min_width=5, )
                                delete_user = gr.Button('➖ Delete User', min_width=5, elem_id='add-user-btn')
                            
                            def show_add_user_pop_up():
                                return gr.update(visible=True)
                            
                            def show_delete_user_pop_up():
                                return gr.update(visible=True)
                            
                            add_user.click(fn=show_add_user_pop_up, outputs=[add_user_pop_up])
                            delete_user.click(fn=show_delete_user_pop_up, outputs=[delete_user_pop_up])
                        with gr.Row():
                            get_users = api_get('get_users')
                            registered_users_table = gr.Dataframe(pd.DataFrame(get_users['users']) ,interactive=False,)
  
                    def handle_add_user_to_db(username, password, title, pisition, mail, status): # returns registered_users_table, add_user_pop_up, exist_status
                        add_status = checkNadd_user_to_db(username, password, title, pisition, mail, status)
                        if add_status == 'exist':
                            return registered_users_table, gr.update(visible=True), gr.update(visible=True)
                        user_table = api_get('get_users')
                        return pd.DataFrame(user_table['users']), gr.update(visible=False), gr.update(visible=False)
                    
                    def handle_delete_user_from_db(username):# returns registered_users_table, delete_user_pop_up, exist_status
                        delete_status = checkNdelete_user_from_db(username)
                        if delete_status == 'not exist':
                            return registered_users_table, gr.update(visible=True), gr.update(visible=True)
                        user_table = api_get('get_users')
                        return pd.DataFrame(user_table['users']), gr.update(visible=False), gr.update(visible=False)
                    
                    # Add User btn @ #1107
                    add_user_to_db.click(fn=handle_add_user_to_db, inputs=[add_user_name, add_password, add_title, add_position, add_mail, add_status], 
                                            outputs=[registered_users_table, add_user_pop_up, add_exist_status])
                    
                    # delete user btn @ #.1116
                    delete_user_from_db.click(fn=handle_delete_user_from_db, inputs=[delete_user_name], 
                                              outputs=[registered_users_table, delete_user_pop_up, delete_exist_status])
                    
                    with gr.Tab("Component Family"):
                        gr.Markdown("### Component Family tab")
                        
                    with gr.Tab("System Settings"):
                        gr.Markdown("### System Setting tab")
                        
                    with gr.Tab("Logs"):
                        gr.Markdown("### Log tab")
                        
                        with gr.Blocks() as log_data_frame:
                            def get_log_data():
                                log_data = api_get('get_logs')
                                df = pd.DataFrame(log_data['log'])
                                def color_cells(cell):
                                    color = "background-color: #8b2b01;" if (cell != None and cell != '') and int(cell) > 2 else "background-color:  #2ea65a;"
                                    return color
                                return df.style.map(color_cells, subset=['id'])
                            log_table = gr.Dataframe(value=get_log_data(), wrap=True, label="Incomming Server Data", elem_id='data_frame')
                    
                    # Barcode Query Change Clicks and functions
                    def handle_switch(toggle):
                        global is_read_on, is_del_on
                        if toggle == "Stock By Barcode":
                            is_read_on, is_del_on = True, False
                        elif toggle == "Delete By Barcode":
                            is_read_on, is_del_on = False, True
                        else:
                            is_read_on, is_del_on = False, False
                        return
                    
                    def autofocus():
                        global is_read_on, is_del_on
                        if is_read_on or is_del_on:
                            return gr.Textbox(container=False, show_label=False, placeholder="Search by Barcodes", autofocus=True, value='', interactive=True)
                        return gr.Textbox(container=False, show_label=False, placeholder="Search by Barcodes", value='', interactive=False)
                    
                    def freeze():
                        time.sleep(0.3)
                        return
                    
                    def handle_update_log(search_bar, stock_code, description, msd_barcode, quantity, package, thickness, ms_level, temp, location, process, status='in'):
                        global logIn_user_name, is_in_stock
                        a = {
                            "barcode": search_bar,
                            "stock_code": stock_code,
                            "lot_number": "3",
                            "quantity": quantity,
                            "cabinet_name": "3",
                            "placer_person": logIn_user_name,
                            "place_date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "inside_hum_temp": temp,
                            "status": status if not is_in_stock else 'out' if status=='in' else 'in',
                            "outside_start_time": "2024-12-18T12:35:59.838846",
                            "outside_hum_temp": None,
                            "expire_date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "package_type": package,
                            "thickness": thickness,
                            "msl_level": ms_level,
                            "msl_countdown_time": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "picker_person": logIn_user_name,
                            "picking_date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "duration_in_cabinet": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "curing_start_date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "curing_duration": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "curing_end_date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "location": location,
                            "packaging_date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "description": description,
                            "process": process
                            }
                        
                        post_log_req = '/add_log?'
                        req_format = ''
                        for key, val in a.items():
                            val = val if  val  else ''
                            req_format += key + '=' + val + '&'    
                        
                        api_post(post_log_req + req_format[:-1])
                        
                        return
                    
                    def handle_upload_stock(search_bar, stock_code, description, msd_barcode, quantity, package, thickness, ms_level, temp, location, process, status='in'):
                        global logIn_user_name, is_in_stock
                        a = {
                            "barcode": search_bar,
                            "stock_code": stock_code,
                            "lot_number": "3",
                            "quantity": quantity,
                            "cabinet_name": "3",
                            "placer_person": logIn_user_name,
                            "place_date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "inside_hum_temp": temp,
                            "status": status if not is_in_stock else 'out' if status=='in' else 'in',
                            "outside_start_time": "2024-12-18T12:35:59.838846",
                            "outside_hum_temp": None,
                            "expire_date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "package_type": package,
                            "thickness": thickness,
                            "msl_level": ms_level,
                            "msl_countdown_time": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "picker_person": logIn_user_name,
                            "picking_date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "duration_in_cabinet": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "curing_start_date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "curing_duration": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "curing_end_date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "location": location,
                            "packaging_date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            "description": description,
                            }
                        
                        post_log_req = '/add_stock?'
                        req_format = ''
                        for key, val in a.items():
                            val = val if  val  else ''
                            req_format += key + '=' + val + '&'    
                        
                        api_post(post_log_req + req_format[:-1])
                        
                        return
                    
                    def handle_update_stock(search_bar, stock_code, description, msd_barcode, quantity, package, thickness, ms_level, temp, location, process, status='in'):
                        global logIn_user_name
                        updated_stock_data = {
                                "Place_Date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                                "Status": 'out' if status=='in' else 'in',
                                "Picker_Person": logIn_user_name,
                                "Picking_Date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                                "Duration_In_Cabinet": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                                "Curing_Start_Date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                                "Curing_Duration": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                                "Curing_End_Date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                                "Packaging_Date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f"),
                            }
                        requests.put(f"{BASE_URL}/update_stock/{search_bar}",json=updated_stock_data)
                        
                        return
                    
                     
                    def handle_barcode_search(search_bar, stock_code, description, msd_barcode, quantity, package, thickness, ms_level, temp, location):
                        global barcode_data, is_in_stock, is_del_on
                        pop_up_update_arr = []
                        if search_bar != '':
                            get_stock_respond = requests.get(f"{BASE_URL}get_stock/{search_bar}")
                            if get_stock_respond.status_code == 200:
                                barcode_data = get_stock_respond.json()
                                is_in_stock = True
                                pop_up_update_arr = [
                                    barcode_data['stock']['stock_code'],
                                    barcode_data['stock']['description'],
                                    barcode_data['stock']['barcode'],
                                    barcode_data['stock']['quantity'],
                                    barcode_data['stock']['package_type'],
                                    barcode_data['stock']['thickness'],
                                    barcode_data['stock']['msl_level'],
                                    barcode_data['stock']['inside_hum_temp'],
                                    barcode_data['stock']['location'],]
                                
                                if is_del_on:
                                    requests.delete(f"{BASE_URL}/delete_stock?Barcode={search_bar}")
                                    handle_update_log(search_bar, *pop_up_update_arr, 'deleted', 'out')    
                                else:
                                    handle_update_log(search_bar, *pop_up_update_arr, barcode_data['stock']['status'] + 'Stock', barcode_data['stock']['status']) 
                                    handle_update_stock(search_bar, *pop_up_update_arr, barcode_data['stock']['status'] + 'Stock', barcode_data['stock']['status'])
                            elif get_stock_respond.status_code == 500 and not is_del_on:
                                product_data = api_get(f'their_db/{search_bar}')
                                is_in_stock = False
                                barcode_data = product_data['data'][0]
                                pop_up_update_arr = [
                                    gr.update(value=product_data['data'][0]['stock_code']),
                                    gr.update(value=product_data['data'][0]['description']),
                                    gr.update(value=product_data['data'][0]['barcode']),
                                    gr.update(value=product_data['data'][0]['quantity']),
                                    gr.update(value=product_data['data'][0]['package_type']),
                                    gr.update(value=product_data['data'][0]['thickness']),
                                    gr.update(value=product_data['data'][0]['msl_level']),
                                    gr.update(value=product_data['data'][0]['temp']),
                                    gr.update(value=product_data['data'][0]['location']),  
                                ]
                        else:
                            pop_up_update_arr = [stock_code, description, msd_barcode, quantity, package, thickness, ms_level, temp, location]
                        
                        return (gr.update(visible=True if (search_bar and not is_in_stock) else False), *pop_up_update_arr)
                    
                    def handle_update_logNstock(search_bar, stock_code, description, msd_barcode, quantity, package, thickness, ms_level, temp, location):
                        handle_upload_stock(search_bar, stock_code, description, msd_barcode, quantity, package, thickness, ms_level, temp, location, 'In Stock', 'in')
                        handle_update_log(search_bar, stock_code, description, msd_barcode, quantity, package, thickness, ms_level, temp, location, 'In Stock', 'in')
                        
                        return
                    
                    def update_stock_ui():
                        stock_data = pd.DataFrame(api_get('get_stocks')['stocks'])
                        stock_data.insert(0, 'id', range(1, len(stock_data) + 1)) 
                        def get_log_data():
                                log_data = api_get('get_logs')
                                df = pd.DataFrame(log_data['log'])
                                def color_cells(cell):
                                    color = "background-color: #8b2b01;" if (cell != None and cell != '') and int(cell) > 2 else "background-color:  #2ea65a;"
                                    return color
                                return df.style.map(color_cells, subset=['id']) 
                        return gr.update(value=stock_data), gr.update(value=get_log_data())
                    
                    def pop_up_close_by_save_btn():
                        return gr.update(visible=False)
                    
                    read_delete_toggle.change(fn=handle_switch, inputs=[read_delete_toggle]
                                              ).then(fn=autofocus, outputs=[search_bar])
                    
                    search_bar.change(fn=freeze
                                        ).then(fn=handle_barcode_search,
                                                inputs=[search_bar, stock_code, description, msd_barcode, quantity, package, thickness, ms_level, temp, location],
                                                outputs=[query_pop_up, stock_code, description, msd_barcode, quantity, package, thickness, ms_level, temp, location]
                                        ).then(fn=update_stock_ui, outputs=[stock_table, log_table])
                                        
                    save_button.click(fn=pop_up_close_by_save_btn, outputs=[query_pop_up]
                                       ).then(fn=handle_update_logNstock, 
                                       inputs=[search_bar, stock_code, description, msd_barcode, quantity, package, thickness, ms_level, temp, location]
                                       ).then(fn=update_stock_ui, outputs=[stock_table, log_table])               
            ################################################################################################################################
                
                with gr.Tab("Help"):
                    gr.Markdown("### Help tab")
                

                
            login_btn.click(fn=handle_login, inputs=[user_name, password], 
                            outputs=[login_pop_up, main_block, login_status])
            
            # Dijital saati 1 sn de 1 update ederek gösterir
            gr.HTML("<div style='flex: 1; height:310px;'></div>")  # Üstteki öğeler ile zaman göstergesinin arasına boşluk ekler.
            time_display = gr.Label(update_time(), elem_classes="time-display", container=False)  # Canlı zaman gösterimi
            timer = gr.Timer(value=1, active=True)  # Zamanı her saniye günceller.
            timer.tick(fn=update_time, outputs=time_display)
                
        # Oswald.ttf ve DSFONT.ttf dosyalarının yolunu base_dir kullanarak oluştur
        allowed_paths = [
            os.path.join(base_dir, "Ayarlar", "Oswald.ttf"),
            os.path.join(base_dir, "Ayarlar", "DSFONT.ttf")
        ]

        # SadeceLogo.png dosyasının yolunu base_dir kullanarak oluştur
        favicon_path = os.path.join(base_dir, "Ayarlar", "SadeceLogo.png")

        # app.launch fonksiyonunda dinamik yolları kullan
        app.launch(allowed_paths=allowed_paths, inbrowser=True, favicon_path=favicon_path)

def get_uuid(): 
    try:
        result = subprocess.run(['blkid', '-s', 'UUID', '-o', 'value', '/dev/nvme0n1p2'], capture_output=True, text=True, check=True)
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        print(f"Hata: {e}")
        return None


    # Uygulama başlatılıyor.
ui = UserInterface()
ui.createUI()


