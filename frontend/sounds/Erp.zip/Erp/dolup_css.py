css = """
@font-face {
    font-family: 'Oswald';
    src: url('/file=Ayarlar/Oswald.ttf') format('truetype');
}

@font-face {
    font-family: 'DS-DIGIB';
    src: url('Ayarlar/DS-DIGIB.TTF') format('truetype');
}
.info-box {
    padding: 10px;
    border: 1px gray solid;
    border-radius: 10px;
}

.time-display h2 {
    font-family: 'DS-DIGIB', sans-serif;
    font-size: 30pt;
    color: white;
    position: fixed;
    bottom: 0.6%;
    left: 2%;   
    z-index: 2000;
    padding: 0;
    margin-top: auto; /* En alta itilmesini sağlar */
}

.logo-gozle {
    display: flex;
    justify-content: flex-start;
    position: fixed;
    top: -15px;
    left: -15px;
    z-index: 1500;
    padding: 0;
    width: 21%;
    height: 10%;
}

.logo-ilge {
    display: flex;
    justify-content: flex-end;
    position: fixed;
    bottom: 2%;
    right: 2%;
    z-index: 1500;
    padding: 0;
    width: 21%;
    height: 3%;
}

.header_hidden{
    position: relative;
    margin-top: 3%;
}

.footer_hidden {
    height: 10%;
}

.footer_title_hidden {
    font-size: 11pt;
}

.start-button, .stop-button {
    border: none;
    color: #ffffff;
    font-weight: bold;
    font-family: 'Oswald', sans-serif;
    font-size: 20pt;
    cursor: pointer;
}

.run-button img {
    width: 60px;  /* İkonun genişliğini ayarlayın */
    height: 60px; /* İkonun yüksekliğini ayarlayın */
}

#process-container {
    display: flex;
    justify-content: space-between;
    padding: 10px 50px 30px 50px;
}

.good-product-display h2 {
    font-family: 'Oswald', sans-serif;
    font-size: 30pt;
    color: green;
    position: relative; /* Konumlandırma */
    padding-top: 10;
    margin-top: auto; /* En alta itilmesini sağlar */
}

.defective-product-display h2 {
    font-family: 'Oswald', sans-serif;
    font-size: 30pt;
    color: red;
    position: relative; /* Konumlandırma */
    padding-top: 10;
    margin-top: auto; /* En alta itilmesini sağlar */
}

.total-product-display h2 {
    font-family: 'Oswald', sans-serif;
    font-size: 30pt;
    color: white;
    position: relative; /* Konumlandırma */
    padding-top: 10;
    margin-top: auto; /* En alta itilmesini sağlar */
}
.efficiency-display h2 {
    font-family: 'Oswald', sans-serif;
    font-size: 30pt;
    color: cyan;
    position: relative; /* Konumlandırma */
    padding-top: 10;
    margin-top: auto; /* En alta itilmesini sağlar */
}

#header_row {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    background-color: #003366;
    margin-left: 0;
    position: fixed;
    top: 0;
    left: 0;
    height: 7%;
    width: 100%;
    box-shadow: 0 -2px 5px rgba(0,0,0,0.2);
    z-index: 1000;
}

.header_title {
    display: flex;
    align-items: center;
    height: 100%;
    justify-content: center;
    font-family: 'Oswald', sans-serif;
    font-size: 2vw;
    letter-spacing: 2px;
    font-weight: bold;
    text-align: center;
    margin-left: 10px;
    width: 100%;
    color: #fff;
    padding: 10px;
}

.footer {
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #003366;
    color: #fff;
    font-size: 13pt;
    text-align: center;
    padding: 10px 20px;
    position: fixed;
    bottom: 0;
    left: 0;
    height: 7%;
    width: 100%;
    box-shadow: 0 -2px 5px rgba(0,0,0,0.2);
    z-index: 1000;
}

.content {
    margin-top: 80px; /* Header'ın altında boşluk bırakır */
    margin-bottom: 50px;
    display: flex;
    flex-direction: row;
}

.left-column {
    display: flex;
    flex-direction: column;
    justify-content: space-between;  /* Zaman göstergesini en alta iter */
    width: 25%;
    height: 100vh; /* Yüksekliği tüm görünüm alanını kaplayacak şekilde ayarlar */
}

.right-column {
    display: flex;
    
    flex-direction: column;
    width: 75%;
}

.logo-genel {
    padding: 0;
    margin: 0;
    flex: 0 0 auto;
    min-width: 40px;  /* Minimum genişliği ayarlıyoruz */
    max-width: 40px;  /* Maksimum genişliği ayarlıyoruz */
    flex-shrink: 1;   /* Container'ın küçülmesini sağlıyoruz */
}

.logo-genel img {
    width: 40px;  /* Resim boyutunu sabitliyoruz */
    height: 40px;
    margin: 0;
    padding: 0;
}

#icons {
    position: fixed;
    justify-content: flex-end;  /* Resimleri sağa yaslamak için */
    top: 1.5%;
    right: 2%;
    display: flex;
    flex-direction: row;  /* Resimleri yatay olarak hizalıyoruz */
    align-items: center;
    z-index: 1500;
    width: 20%; /* Butonların toplam genişliği kapsayıcıdan taşmayacak */
    padding: 0;
    margin: 0;
}

#icons img {
    width: 30px;  /* İkonun genişliğini ayarlayın */
    height: 30px; /* İkonun yüksekliğini ayarlayın */
}

.header-buttons {
    background: transparent;
    padding: 0;
    margin: 0 5px; /* Butonlar arasında boşluk bırakmak için */
    border: none;
    flex: 0 0 auto; /* Butonların genişliğini ikon boyutuna göre ayarlayın */
    width: 40px; /* İsteğe bağlı: Buton genişliğini manuel olarak ayarlayın */
    height: 40px; /* İsteğe bağlı: Buton yüksekliğini manuel olarak ayarlayın */
    display: flex; /* Buton içindeki içeriği flex ile hizalamak için */
    justify-content: center; /* İkonu butonun merkezine yerleştirmek için */
    align-items: center; /* Dikey olarak hizalamak için */
}

.motor-buttons {
    background: transparent;
    padding: 0;
    margin: 0 5px; /* Butonlar arasında boşluk bırakmak için */
    border: none;
    flex: 0 0 auto; /* Butonların genişliğini ikon boyutuna göre ayarlayın */
    width: 40px; /* İsteğe bağlı: Buton genişliğini manuel olarak ayarlayın */
    height: 40px; /* İsteğe bağlı: Buton yüksekliğini manuel olarak ayarlayın */
    display: flex; /* Buton içindeki içeriği flex ile hizalamak için */
    justify-content: center; /* İkonu butonun merkezine yerleştirmek için */
    align-items: center; /* Dikey olarak hizalamak için */
}

#popup_box , #acil_popup_box{
    background-color: transparent;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    padding: 30px;
    z-index: 9999;
    width: 25%; /* Set the width to make it narrower */
    height: 25%;
    border: none;
}

#overlay { 
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    backdrop-filter: blur(5px);
    z-index: 9998; /* Popup'ın hemen altında */
}

#yes_button {
    background: green;
    color: white;
    margin: 10px;
    letter-spacing:2pt;
    padding:15px 30px;
    font-family: 'Oswald', sans-serif;
    font-size: 1.2rem;
    border-radius: 25px;
    cursor:pointer;
    transition: background-color 0.3s ease; 
}

#no_button {
    background: red;
    color: white;
    margin: 10px;
    letter-spacing:2pt;
    padding:15px 30px;
    font-family: 'Oswald', sans-serif;
    border-radius: 25px;
    cursor:pointer;
    transition: background-color 0.3s ease;
}

#popup_text {
    text-align: center;
    font-family: 'Oswald', sans-serif;
    font-size: 1.5rem;
    letter-spacing:2pt;
    margin-bottom: 20px
}

#acil_popup_text{
    background: red;
    color: red;
    text-align: center;
    font-family: 'Oswald', sans-serif;
    font-size: 2rem;
    letter-spacing: 2pt;
    margin: 20px;
}

#yes_button:hover {
background-color: darkgreen; /* Buton üzerine gelindiğinde rengi koyulaştır */
}

#no_button:hover {
    background-color: darkred; /* Buton üzerine gelindiğinde rengi koyulaştır */
}
/* Custom defined classes for dradio elements*/

#toggle-barcode{
    display: flex;
    align-items: center;
    justify-content: left;
    padding: 5px;   
}

.tab-container button{
    font-size: 18px;
}

.svelte-s3jb61 p{
    font-size: 17px;
    font-weight: 600;
}

#setting-block{
    background: #18181b;
    margin-top: 20px;
}
#float-div,
#login-float-div{
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: rgba(0, 51, 102, 1);
    color: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    font-family: 'Arial', sans-serif;
    z-index: 1000;
    width: 900px;
    max-width: 90%;
    text-align: left;
    animation: fadeIn 0.2s ease-in-out;
}

#login-float-div{
    width: 400px;
}


#float-div .gr-dropdown {
    position: relative;
    z-index: 2000;
    width: 100%;
}

#float-div .gr-dropdown .dropdown-menu {
    position: absolute;
    top: 100%;
    left: 0;
    background-color: white;
    color: black;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    min-width: 100%;
    display: none;
}

#float-div .gr-dropdown:hover .dropdown-menu {
    display: block;
}

/* Close button (X mark) */
#close-btn {
    position: absolute;
    text-align: center;
    top: 7px;
    right: 7px;

    background: #52525b;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    border: none;
    font-size: 14px;
    cursor: pointer;
    z-index: 2001;
}

#logIn-header {
    font-size: 24px;  
    font-weight: bold;
    text-align: center;
}

.user-details {
    font-size: 20px; 
    color: #333; 
    margin: 10px;
    max-width: 400px; 
}

.user-row {
    display: flex; 
    justify-content: space-between;
    margin: 8px 0;
}

.field-name {
    font-weight: bold; 
    width: 40%; 
    text-align: left; 
}

.field-value {
    width: 60%; 
    text-align: left; 
}

#user-foto .prose{
    display: flex;
    justify-content: center;
    align-items: center;
}

#username-div{
    background-color: rgba(0, 51, 102, 1);
}

/* Fade-in effect */
.cabinet-container {
    display: flex;
    flex-wrap: wrap;    
    gap: 20px;
}

.cabinet:hover{
    cursor: pointer;
}

.cabinet {
    width: 100px;
    height: 200px;
    border: 2px solid black;
    border-radius: 5px;
    display: flex;
    flex-direction: row;
    background-color: #f9f9f9;
    box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
}


.cabinet:hover{
    cursor: pointer;
}

.cabinet .left-panel {
    width: 20%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.cabinet .left-panel .handle {
    width: 5px;
    height: 40px;
    background-color: white;
    border-radius: 2px;
}

.cabinet .right-panel {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 5px;
    padding: 5px;
}

.cabinet.type-1 {
    border-color: #0077ff;
    background-image: linear-gradient(to bottom, #e0f7ff, #b3eaff);
}

.cabinet.type-1 .left-panel {
    background-color: #0077ff;
}

.cabinet.type-1 .right-panel {
    background-image: radial-gradient(circle, #ffffff, #cce7ff);
}

.cabinet.type-1 .right-panel .door {
    flex: 1;
    background-color: #80d4ff;
    border: 1px solid #0077ff;
    border-radius: 5px;
}

.cabinet.type-2 {
    border-color: #ff6600;
    background-image: linear-gradient(to bottom, #ffe0cc, #ffb399);
}

.cabinet.type-2 .left-panel {
    background-color: #ff6600;
}

.cabinet.type-2 .right-panel {
    background-color: #ff9966;
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 5px;
}

.cabinet.type-2 .right-panel .door {
    background-color: #ffcc99;
    border: 2px dashed #ff6600;
    border-radius: 5px;
}

.cabinet.type-3 {
    border-color: #333333;
    background-image: linear-gradient(to bottom, #cccccc, #999999);
}

.cabinet.type-3 .left-panel {
    background-color: #666666;
}

.cabinet.type-3 .right-panel {
    background-color: #b3b3b3;
    display: flex;
    flex-direction: column;
    gap: 5px;
    align-items: center;
}

.cabinet.type-3 .right-panel .door {
    width: 80%;
    height: 20px;
    background-color: #999999;
    border: 1px solid #666666;
    border-radius: 3px;
}

.cabinet-label {
    text-align: center;
    font-size: 14px;
    font-weight: bold;
    margin-top: 5px;
}

#add-cabinet-btn{
    width: 200px;
}

#add-del-btn-container{
    display: flex;
    justify-content: flex-end;
}

#add-user-btn {
    max-width: 160px;
    align-item: left;
}

#toggle-barcode {
    transform: scale(1.2);
    transform-origin: left center;
}


/* Fade-in effect */
@keyframes fadeIn {
    0% {
        opacity: 0;
    }
    100% {
        opacity: 1;
    }
}


"""


